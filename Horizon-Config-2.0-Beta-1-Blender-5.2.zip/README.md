# Horizon Config 2.0

**Evolved from HEAVYPOLY Config. Maintained by Hao / Horizon Workshop.**

Horizon Config 2.0 is an independent continuation of the HEAVYPOLY Blender
workflow, updated and compatibility-repaired for Blender 5.2 LTS.

The project preserves the direct hotkeys, pie-driven modeling language, and
fast material/modifier workflow that made HEAVYPOLY distinctive while repairing
degraded APIs and establishing a maintainable path forward.

## Beta 1

Beta 1 includes:

- 185 managed HC hotkeys with clean registration and removal
- A large HC Mapping ↔ Vanilla switch in the 3D Viewport `N` sidebar
- Native Object/Edit `Tab` behavior restored in Vanilla mapping
- Repaired pies, Flip, Flatten, Rotate 90, mirrors, symmetry, Unhide, and Origin
- Shade Smooth behavior for standard and subdivided objects
- Managed Boolean cutters and scene-wide visibility/enable controls
- View-oriented Edit-mode Duplicate Radial
- Compact Shift+V material creation and slot workflow
- One-click inverted-hull HC Outline
- Eevee viewport-compositor Bloom, enabled by default at `0.05`
- Windows and macOS portable installation layouts

Chromatic aberration, film grain, and stylized color experiments are not part
of this release. The Beta retains the last known-working Bloom-only compositor.

## Compatibility

This release targets **Blender 5.2 LTS**. Historical `HEAVYPOLY_*` module names
and operator identifiers remain internally so existing hotkeys and `.blend`
workflows are less likely to break.

Grease Pencil expansion and the Geometry Nodes workflow redesign remain future
development phases.

## Install

Download `Horizon-Config-2.0-Beta-1-Blender-5.2.zip` and read
[`README_INSTALL.md`](README_INSTALL.md) before copying files. Portable installs
are recommended on both Windows and macOS because this package includes
`startup.blend` and `userpref.blend`.

## Lineage

Horizon Config 2.0 is evolved from the original **HEAVYPOLY Config** created by
Vaughan Ling, with contributions from Julien Gauthier and the HEAVYPOLY
community. It is an independent continuation rather than an official
HEAVYPOLY release.

Read [`MANIFESTO.md`](MANIFESTO.md) for the full project statement.

## Maintenance

Horizon Config 2.0 is maintained by **Hao / Horizon Workshop**.
