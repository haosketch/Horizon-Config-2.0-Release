bl_info = {
    "name": "Pie Shading",
    "description": "Shading Modes",
    "author": "Vaughan Ling",
    "version": (1, 1, 0),
    "blender": (5, 2, 0),
    "location": "",
    "warning": "",
    "wiki_url": "",
    "category": "Pie Menu"
    }

import bpy
import math
from bpy.types import Menu
from bpy.props import PointerProperty


HP_BLOOM_NODE = "HC Bloom"
HP_BLOOM_TREE = "Horizon Config 2.0 Bloom"
LEGACY_BLOOM_NODE = "HEAVYPOLY Bloom"
REMOVED_POST_FX_NODES = (
    "HC Chromatic Aberration",
    "HC Film Grain",
    "HC Stylized Color",
    "HC Separate RGB",
    "HC Red Shift",
    "HC Blue Shift",
    "HC Grain Texture",
    "HC Grain Coordinates",
)


def _find_bloom_node(scene):
    tree = scene.compositing_node_group
    if not tree:
        return None
    return tree.nodes.get(HP_BLOOM_NODE) or tree.nodes.get(LEGACY_BLOOM_NODE)


def _ensure_compositor_output(tree):
    output = next((node for node in tree.nodes if node.bl_idname == 'NodeGroupOutput'), None)
    if output is None:
        image_output = next(
            (
                item for item in tree.interface.items_tree
                if item.item_type == 'SOCKET' and item.in_out == 'OUTPUT' and item.name == 'Image'
            ),
            None,
        )
        if image_output is None:
            tree.interface.new_socket(
                name='Image',
                in_out='OUTPUT',
                socket_type='NodeSocketColor',
            )
        output = tree.nodes.new('NodeGroupOutput')
        output.name = "HC Bloom Output"
        output.location = (520.0, 0.0)
    return output


def _ensure_bloom_node(scene):
    tree = scene.compositing_node_group
    if tree is None:
        tree = bpy.data.node_groups.new(HP_BLOOM_TREE, 'CompositorNodeTree')
        scene.compositing_node_group = tree
        scene.use_nodes = True

    output = _ensure_compositor_output(tree)
    image_input = output.inputs.get('Image')
    if image_input is None:
        raise RuntimeError("Compositor output has no Image input")

    node = _find_bloom_node(scene)
    source_socket = None
    if node is not None and node.inputs['Image'].is_linked:
        source_socket = node.inputs['Image'].links[0].from_socket
    elif image_input.is_linked:
        candidate = image_input.links[0].from_socket
        if candidate.node.name not in REMOVED_POST_FX_NODES:
            source_socket = candidate

    # Remove every abandoned experimental effect from existing Alpha 6-10
    # files. Bloom is reconnected directly to the compositor output below.
    for name in REMOVED_POST_FX_NODES:
        obsolete = tree.nodes.get(name)
        if obsolete is not None:
            tree.nodes.remove(obsolete)

    if source_socket is None:
        render_layers = next(
            (node for node in tree.nodes if node.bl_idname == 'CompositorNodeRLayers'),
            None,
        )
        if render_layers is None:
            render_layers = tree.nodes.new('CompositorNodeRLayers')
            render_layers.name = "HC Render Layers"
            render_layers.location = (-420.0, 0.0)
        source_socket = render_layers.outputs.get('Image')

    if node is None:
        node = tree.nodes.new('CompositorNodeGlare')
    node.name = HP_BLOOM_NODE
    node.label = "HC Bloom"
    node.location = (140.0, 0.0)
    node.inputs['Type'].default_value = 'Fog Glow'
    node.inputs['Quality'].default_value = 'Medium'
    node.inputs['Threshold'].default_value = 1.0
    node.inputs['Size'].default_value = 0.55
    for link in list(node.inputs['Image'].links):
        tree.links.remove(link)
    for link in list(image_input.links):
        tree.links.remove(link)
    tree.links.new(source_socket, node.inputs['Image'])
    tree.links.new(node.outputs['Image'], image_input)
    return node


def _set_viewport_compositor(context, enabled):
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            if area.type != 'VIEW_3D':
                continue
            shading = area.spaces.active.shading
            shading.use_compositor = 'ALWAYS' if enabled else 'DISABLED'
            if enabled and area == context.area:
                shading.type = 'RENDERED'


def _update_bloom(self, context):
    scene = self.id_data if isinstance(self.id_data, bpy.types.Scene) else context.scene
    if self.bloom_enabled:
        node = _ensure_bloom_node(scene)
        node.mute = False
        node.inputs['Strength'].default_value = self.bloom_intensity
        scene.render.engine = 'BLENDER_EEVEE'
    else:
        node = _find_bloom_node(scene)
        if node:
            node.mute = True
    _set_viewport_compositor(context, self.bloom_enabled)


def _update_bloom_intensity(self, context):
    scene = self.id_data if isinstance(self.id_data, bpy.types.Scene) else context.scene
    node = _find_bloom_node(scene)
    if node:
        node.inputs['Strength'].default_value = self.bloom_intensity


class HC_PostFXSettings(bpy.types.PropertyGroup):
    bloom_enabled: bpy.props.BoolProperty(
        name="Bloom",
        description="Enable Horizon Fog Glow in the Eevee viewport compositor",
        default=True,
        update=_update_bloom,
    )
    bloom_intensity: bpy.props.FloatProperty(
        name="Intensity",
        description="Strength of the viewport bloom",
        default=0.05,
        min=0.0,
        max=5.0,
        soft_max=0.5,
        update=_update_bloom_intensity,
    )


class HP_OT_bloom_toggle(bpy.types.Operator):
    bl_idname = "view3d.hp_bloom_toggle"
    bl_label = "Toggle Bloom"
    bl_description = "Toggle Eevee viewport bloom using the real-time compositor"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.hc_post_fx
        settings.bloom_enabled = not settings.bloom_enabled
        return {'FINISHED'}

class HP_MT_pie_shading(Menu):
    bl_label = "Shading"
    bl_space_type = 'VIEW_3D'
    def draw(self, context):

        layout = self.layout

        view = context.space_data
        shading = view.shading
        obj = context.active_object
        overlay = view.overlay
        tool_settings = context.tool_settings
        object_mode = 'OBJECT' if obj is None else obj.mode
        pie = layout.menu_pie()
        #LEFT
        pie.prop_enum(view.shading, "type", value='WIREFRAME', icon = 'NONE', text = 'WIRE')
        #RIGHT
        
        split = pie.split()
        #BOTTOM
        # split = pie.split()
        # col = split.column(align=True)
        # row = col.row(align=True)
        # row.scale_y=1.5
        # row.operator('popup.hp_properties', text='World Settings').type='WORLD'
        # row = col.row(align=True)
        # row.scale_y=1.5
        # row.operator('popup.hp_render', text='Render Settings')
        # row = col.row(align=True)
        # row.scale_y=1.5
        # row.operator('render.render', text='Render Animation').animation=True
        # row = col.row(align=True)
        # row.scale_y=1.5
        # row.operator('render.render', text='Render Image')
        view = context.space_data
        
        pie.operator('view3d.localview', text='ISOLATE').frame_selected = False
        #TOP
        pie.prop_enum(view.shading, "type", value='MATERIAL', icon = 'NONE', text = 'MATERIAL')

        #TOP LEFT
        pie.prop_enum(view.shading, "type", value='SOLID', icon = 'NONE', text = 'SOLID')

        #TOP RIGHT
        pie.prop_enum(view.shading, "type", value='RENDERED', icon = 'NONE', text = 'RENDERED')

        #BOTTOM LEFT
        split = pie.split()
        col = split.column(align=True)
        row = col.row(align=True)
        row.scale_y=1.5
        settings = context.scene.hc_post_fx
        bloom_icon = int(bpy.app.driver_namespace.get('HC_BLOOM_ICON_ID', 0))
        row.operator(
            "view3d.hp_bloom_toggle",
            text="BLOOM ON" if settings.bloom_enabled else "BLOOM OFF",
            icon_value=bloom_icon,
        )
        row = col.row(align=True)
        row.enabled = settings.bloom_enabled
        row.prop(settings, "bloom_intensity", text="Intensity", slider=True)

        #BOTTOM RIGHT
        split = pie.split()
        col = split.column(align=True)
        col.scale_y=1.4

        box = col.box()
        box.prop(overlay, "show_overlays", text="OVERLAYS")
        box.prop(overlay, "show_extras", text="EXTRAS")
        # box.prop(overlay, "show_backface_culling", text="HIDE BACKFACES")
        box.prop(overlay, "show_cursor", text="3D CURSOR")
        box.operator("object.add_normal_modifier", text='Smooth by Angle')
        box.operator("object.hc_shade_flat", text='Shade Flat')
#        pie.operator("view3d.toggle_background_hide", text="Toggle BG Hide")


class HP_OT_shading_wire(bpy.types.Operator):
    bl_idname = "shading.wire"
    bl_label = "hp_shading_wire"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        bpy.ops.view3d.toggle_shading(type='WIREFRAME')
        bpy.context.space_data.shading.show_xray = True
        bpy.context.space_data.shading.xray_alpha = 1
        bpy.context.space_data.shading.show_object_outline = 1
        
        return {'FINISHED'}
    
class HP_OT_shading_material(bpy.types.Operator):
    bl_idname = "shading.material"
    bl_label = "hp_shading_material"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        bpy.ops.view3d.toggle_shading(type='MATERIAL')
        bpy.context.space_data.shading.show_xray = False
        bpy.context.space_data.shading.xray_alpha = 0
        return {'FINISHED'}
    
class HP_OT_shading_solid(bpy.types.Operator):
    bl_idname = "shading.solid"
    bl_label = "hp_shading_wire"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        bpy.ops.view3d.toggle_shading(type='SOLID')
        bpy.context.space_data.shading.show_xray = False
        bpy.context.space_data.shading.xray_alpha = 0
        return {'FINISHED'}
        
class HP_OT_shading_rendered(bpy.types.Operator):
    bl_idname = "shading.rendered"
    bl_label = "hp_shading_rendered"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        bpy.ops.view3d.toggle_shading(type='RENDERED')
        bpy.context.space_data.shading.show_xray = False
        bpy.context.space_data.shading.xray_alpha = 0
        return {'FINISHED'}
        
class HP_OT_shading_bg_wire(bpy.types.Operator):
    bl_idname = "shading.bg_wire"
    bl_label = ""
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        for ob in bpy.context.selected_objects:
            ob.display_type = 'TEXTURED'
        bpy.ops.object.select_all(action='INVERT')
        for ob in bpy.context.selected_objects:
            ob.display_type = 'WIRE'
        bpy.ops.object.select_all(action='INVERT')
        return {'FINISHED'}
    
####### Smooth by Angle

HC_SMOOTH_ID_KEY = "hc_smooth_by_angle_id"
HC_SMOOTH_ID = "horizon.config.smooth_by_angle.v1"
HC_SMOOTH_SCHEMA_KEY = "hc_smooth_by_angle_schema"
HC_SMOOTH_SCHEMA = 3


def is_horizon_smooth_modifier(modifier):
    """Recognize complete and partially installed smoothers by their node group."""
    if modifier.type != 'NODES' or modifier.node_group is None:
        return False
    return modifier.node_group.get(HC_SMOOTH_ID_KEY) == HC_SMOOTH_ID


def _smooth_by_angle_group():
    """Reuse our current group while recognizing older groups for migration."""
    for tree in bpy.data.node_groups:
        if (
            tree.bl_idname == 'GeometryNodeTree'
            and tree.get(HC_SMOOTH_ID_KEY) == HC_SMOOTH_ID
            and tree.get(HC_SMOOTH_SCHEMA_KEY) == HC_SMOOTH_SCHEMA
        ):
            return tree

    tree = bpy.data.node_groups.new("HC Smooth by Angle", 'GeometryNodeTree')
    try:
        tree.is_modifier = True
        tree.interface.new_socket(name="Geometry", in_out='INPUT', socket_type='NodeSocketGeometry')
        tree.interface.new_socket(name="Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')
        angle_socket = tree.interface.new_socket(
            name="Angle", in_out='INPUT', socket_type='NodeSocketFloat',
        )
        angle_socket.subtype = 'ANGLE'
        angle_socket.default_value = math.radians(25)
        angle_socket.min_value = 0.0
        angle_socket.max_value = math.pi
        angle_socket.description = "Smooth evaluated edges at or below this angle"
        if hasattr(angle_socket, 'force_non_field'):
            angle_socket.force_non_field = True
        inputs = tree.nodes.new('NodeGroupInput')
        inputs.location = (-520, 100)
        outputs = tree.nodes.new('NodeGroupOutput')
        outputs.location = (360, 100)
        edge_angle = tree.nodes.new('GeometryNodeInputMeshEdgeAngle')
        edge_angle.location = (-520, -200)
        compare = tree.nodes.new('FunctionNodeCompare')
        compare.data_type = 'FLOAT'
        compare.operation = 'LESS_EQUAL'
        compare.location = (-280, -200)
        compare.label = "Edge angle <= smoothing angle"
        edge_smooth = tree.nodes.new('GeometryNodeSetShadeSmooth')
        edge_smooth.domain = 'EDGE'
        edge_smooth.inputs['Selection'].default_value = True
        edge_smooth.location = (80, 100)
        edge_smooth.label = "Split evaluated normals by angle"

        # Keep the original face shading flags: native Shade Flat must still
        # work while this modifier is enabled. Only edge normal splits change.
        tree.links.new(inputs.outputs['Geometry'], edge_smooth.inputs['Geometry'])
        tree.links.new(edge_angle.outputs['Unsigned Angle'], compare.inputs['A'])
        tree.links.new(inputs.outputs['Angle'], compare.inputs['B'])
        tree.links.new(compare.outputs['Result'], edge_smooth.inputs['Shade Smooth'])
        tree.links.new(edge_smooth.outputs['Geometry'], outputs.inputs['Geometry'])
        tree[HC_SMOOTH_ID_KEY] = HC_SMOOTH_ID
        tree[HC_SMOOTH_SCHEMA_KEY] = HC_SMOOTH_SCHEMA
        return tree
    except Exception:
        bpy.data.node_groups.remove(tree)
        raise


def _set_smooth_angle(modifier, identifier, value):
    """Use 5.2 RNA input sockets, with legacy socket storage for older Blender."""
    inputs = getattr(getattr(modifier, 'properties', None), 'inputs', None)
    if inputs is not None:
        socket = getattr(inputs, identifier, None)
        if socket is None or not hasattr(socket, 'value'):
            raise KeyError(f"Geometry Nodes input '{identifier}' was not found")
        socket.value = float(value)
    else:
        # Blender <= 5.0 stores declared node inputs here. This is never used
        # for ownership tags or when the 5.2 RNA socket collection is present.
        modifier[identifier] = float(value)


def add_smooth_by_angle(context, obj, angle=math.radians(25)):
    """Compute angle shading on evaluated geometry; leave the edit cage unmarked."""
    if obj.type != 'MESH':
        return

    tree = _smooth_by_angle_group()
    angle_socket = next(
        item for item in tree.interface.items_tree
        if item.item_type == 'SOCKET' and item.in_out == 'INPUT' and item.name == 'Angle'
    )
    original_active = context.view_layer.objects.active
    original_mode = original_active.mode if original_active else 'OBJECT'
    if original_active and original_mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')
    try:
        owned_modifiers = [mod for mod in obj.modifiers if is_horizon_smooth_modifier(mod)]
        modifier = owned_modifiers[0] if owned_modifiers else None
        if modifier is None:
            modifier = obj.modifiers.new("HC Smooth by Angle", 'NODES')
        modifier.node_group = tree
        _set_smooth_angle(modifier, angle_socket.identifier, angle)
        # Recover duplicate/partial smoothers created before the old 5.2
        # modifier-ID-property failure, without touching unrelated modifiers.
        for duplicate in owned_modifiers[1:]:
            obj.modifiers.remove(duplicate)
        modifier.show_viewport = True
        modifier.show_render = True
        modifier.show_in_editmode = True
        modifier.show_on_cage = False
        if obj.modifiers[-1] != modifier:
            # Evaluate angles after the shape modifiers, preserving every
            # unrelated modifier's settings and relative stack order.
            with context.temp_override(object=obj, active_object=obj):
                bpy.ops.object.modifier_move_to_index(
                    modifier=modifier.name, index=len(obj.modifiers) - 1,
                )

        # Clear marks written by the old implementation. The node modifier
        # computes normal splits without writing sharp flags to editable edges.
        for edge in obj.data.edges:
            edge.use_edge_sharp = False
        for face in obj.data.polygons:
            face.use_smooth = True
        obj.data.update()
        obj.update_tag()
    finally:
        if original_active and original_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode=original_mode)


def shade_flat(context, obj):
    """Remove only Horizon's angle smoothers and restore flat base-face shading."""
    if obj.type != 'MESH':
        return
    original_active = context.view_layer.objects.active
    original_mode = original_active.mode if original_active else 'OBJECT'
    if original_active and original_mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')
    try:
        for modifier in list(obj.modifiers):
            if is_horizon_smooth_modifier(modifier):
                obj.modifiers.remove(modifier)
        for face in obj.data.polygons:
            face.use_smooth = False
        obj.data.update()
        obj.update_tag()
    finally:
        if original_active and original_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode=original_mode)


# Operator retained under its historical idname so existing hotkeys keep working.
class HP_OT_add_normal_modifier(bpy.types.Operator):
    bl_idname = "object.add_normal_modifier"
    bl_label = "Shade Smooth by Angle"
    bl_description = "Smooth by angle without changing shape or marking editable edges sharp"
    bl_options = {'REGISTER', 'UNDO'}

    angle: bpy.props.FloatProperty(
        name="Angle",
        subtype='ANGLE',
        default=math.radians(25),
        min=0.0,
        max=math.pi,
    )

    @classmethod
    def poll(cls, context):
        return any(obj.type == 'MESH' for obj in context.selected_objects)

    def execute(self, context):
        selected_meshes = [obj for obj in context.selected_objects if obj.type == 'MESH']
        for obj in selected_meshes:
            add_smooth_by_angle(context, obj, self.angle)

        return {'FINISHED'}


class HP_OT_shade_flat(bpy.types.Operator):
    bl_idname = "object.hc_shade_flat"
    bl_label = "Shade Flat"
    bl_description = "Remove Horizon angle smoothing and restore flat shading without changing shape"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return any(obj.type == 'MESH' for obj in context.selected_objects)

    def execute(self, context):
        selected_meshes = [obj for obj in context.selected_objects if obj.type == 'MESH']
        for obj in selected_meshes:
            shade_flat(context, obj)
        return {'FINISHED'}


classes = (
    HC_PostFXSettings,
    HP_OT_bloom_toggle,
    HP_MT_pie_shading,
    HP_OT_shading_wire,
    HP_OT_shading_material,
    HP_OT_shading_solid,
    HP_OT_shading_rendered,
    HP_OT_shading_bg_wire,
    HP_OT_add_normal_modifier,
    HP_OT_shade_flat,
)
def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.hc_post_fx = PointerProperty(type=HC_PostFXSettings)
    for scene in bpy.data.scenes:
        settings = scene.hc_post_fx
        # The simplified baseline deliberately resets Bloom to the requested
        # default and removes all other experimental Post FX nodes.
        settings.bloom_enabled = True
        settings.bloom_intensity = 0.05
        if settings.bloom_enabled:
            node = _ensure_bloom_node(scene)
            node.mute = False
            node.inputs['Strength'].default_value = 0.05
            scene.render.engine = 'BLENDER_EEVEE'
    if any(scene.hc_post_fx.bloom_enabled for scene in bpy.data.scenes):
        _set_viewport_compositor(bpy.context, True)


def unregister():
    if hasattr(bpy.types.Scene, "hc_post_fx"):
        del bpy.types.Scene.hc_post_fx
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
