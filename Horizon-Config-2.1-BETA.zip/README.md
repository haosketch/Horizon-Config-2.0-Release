# Horizon Config 2.1 BETA — Installation

Requires Blender 5.2.x. Blender is not included in this package.

## Windows

1. Download and extract the Blender 5.2 Windows ZIP from [blender.org](https://www.blender.org/download/).
2. Close Blender.
3. Extract this Horizon Config ZIP into a separate folder.
4. Double-click **Install-Horizon-Config-2.1-BETA.cmd**.
5. When prompted, paste the folder containing **blender.exe**.
6. Launch **blender.exe** from that folder.

The installer backs up files it replaces to a `Horizon-Config-backup-*` folder beside `blender.exe`. Installation includes the Horizon preferences, keymaps and startup scene.

For manual installation, back up any existing `portable` folder, then copy the included **portable** folder beside **blender.exe**.

## macOS

1. Install Blender 5.2 and close it.
2. Duplicate **Blender.app** for your Horizon installation.
3. Control-click the copied app, choose **Show Package Contents**, and open **Contents/Resources**.
4. Back up any existing `portable` folder there, then copy in the included **portable** folder.
5. Launch the copied Blender application.
