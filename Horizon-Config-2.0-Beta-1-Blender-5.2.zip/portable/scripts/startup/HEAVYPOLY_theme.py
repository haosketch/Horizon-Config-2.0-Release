"""Restore the clean Horizon theme and load the orange effect icon."""

import os

import bpy
import bpy.utils.previews


BLOOM_ICON_KEY = "hc_bloom_orange"
BLOOM_ICON_NAMESPACE = "HC_BLOOM_ICON_ID"

# Alpha 3/4 briefly recolored Blender's shared widget theme. Blender stores
# those values in userpref.blend, so merely removing the recolor code does not
# undo it. These are the exact values from the pre-accent HP Config baseline.
CLEAN_THEME = {
    'wcol_pie_menu': {
        'inner': (24 / 255, 24 / 255, 24 / 255, 1.0),
        'inner_sel': (71 / 255, 114 / 255, 179 / 255, 1.0),
        'outline_sel': (36 / 255, 36 / 255, 36 / 255, 1.0),
        'text_sel': (1.0, 1.0, 1.0),
        'roundness': 0.4,
    },
    'wcol_regular': {
        'inner_sel': (71 / 255, 114 / 255, 179 / 255, 1.0),
        'outline_sel': (61 / 255, 61 / 255, 61 / 255, 1.0),
    },
    'wcol_toolbar_item': {
        'inner_sel': (71 / 255, 114 / 255, 179 / 255, 1.0),
        'outline_sel': (61 / 255, 61 / 255, 61 / 255, 1.0),
    },
    'wcol_menu_item': {
        'inner_sel': (71 / 255, 114 / 255, 179 / 255, 1.0),
    },
}

_previews = None


def bloom_icon_id():
    return int(bpy.app.driver_namespace.get(BLOOM_ICON_NAMESPACE, 0))


def restore_clean_theme():
    """Remove the saved Alpha 3/4 global accent from Blender preferences."""
    interface = bpy.context.preferences.themes[0].user_interface
    for widget_name, properties in CLEAN_THEME.items():
        widget = getattr(interface, widget_name)
        for property_name, value in properties.items():
            setattr(widget, property_name, value)


def register():
    global _previews
    restore_clean_theme()
    if _previews is not None:
        return
    icon_path = os.path.join(
        os.path.dirname(__file__), "assets", "hc_bloom_orange.png"
    )
    if not os.path.isfile(icon_path):
        return
    _previews = bpy.utils.previews.new()
    preview = _previews.load(BLOOM_ICON_KEY, icon_path, 'IMAGE')
    bpy.app.driver_namespace[BLOOM_ICON_NAMESPACE] = preview.icon_id


def unregister():
    global _previews
    bpy.app.driver_namespace.pop(BLOOM_ICON_NAMESPACE, None)
    if _previews is not None:
        bpy.utils.previews.remove(_previews)
        _previews = None


if __name__ == "__main__":
    register()
