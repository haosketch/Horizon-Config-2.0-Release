"""Horizon Config 2.1 BETA portable startup marker for Blender 5.2."""

import bpy


VERSION = (2, 1, 0)
RELEASE = "2.1 BETA"


def register():
    print(
        "Horizon Config",
        RELEASE,
        "build",
        ".".join(str(part) for part in VERSION),
        "loaded for Blender",
        bpy.app.version_string,
    )
    print("Based on and credited to HEAVYPOLY Config")


def unregister():
    pass


if __name__ == "__main__":
    register()
