bl_info = {
    "name": "Horizon Config 2.0 Hotkeys",
    "description": "Hotkeys",
    "author": "Vaughan Ling",
    "version": (1, 1, 0),
    "blender": (5, 2, 0),
    "location": "",
    "warning": "",
    "wiki_url": "",
    "category": "Hotkeys"
    }

import bpy
try:
    addon_keymaps
except NameError:
    addon_keymaps = []

try:
    disabled_default_keymaps
except NameError:
    disabled_default_keymaps = []

try:
    vanilla_fallback_keymaps
except NameError:
    vanilla_fallback_keymaps = []

try:
    horizon_keymap_signatures
except NameError:
    horizon_keymap_signatures = set()


def _operator_exists(idname):
    """Return whether an operator is registered in the running Blender build."""
    try:
        category, name = idname.split(".", 1)
        getattr(getattr(bpy.ops, category), name).get_rna_type()
        return True
    except (AttributeError, KeyError):
        return False


def _new_kmi(keymap, idname, *args, **kwargs):
    """Create and remember an add-on keymap item for reliable cleanup."""
    kmi = keymap.keymap_items.new(idname, *args, **kwargs)
    addon_keymaps.append((keymap, kmi))
    return kmi


def _keymap_signature(keymap, kmi):
    """Return the event/operator fields that identify one HC shortcut."""
    return (
        keymap.name,
        kmi.idname,
        kmi.type,
        kmi.value,
        kmi.shift,
        kmi.ctrl,
        kmi.alt,
        kmi.oskey,
        kmi.key_modifier,
        getattr(kmi.properties, "name", ""),
    )


def _remove_vanilla_fallback_keymaps():
    for keymap, kmi in reversed(vanilla_fallback_keymaps):
        try:
            keymap.keymap_items.remove(kmi)
        except (ReferenceError, RuntimeError):
            pass
    vanilla_fallback_keymaps.clear()


def _install_vanilla_fallback_keymaps():
    """Guarantee Blender's native mode-toggle Tab in packaged preferences.

    Old HEAVYPOLY preference files can contain a stale user-keymap override
    that masks Blender's Object Non-modal Tab item even after the HC add-on
    entries are removed. Recreating the Blender 5.2 default in the add-on
    layer makes Vanilla mode deterministic without resetting any other user
    shortcuts or preferences.
    """
    _remove_vanilla_fallback_keymaps()
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon if wm else None
    if kc is None:
        return
    km = kc.keymaps.new(
        "Object Non-modal",
        space_type='EMPTY',
        region_type='WINDOW',
        modal=False,
    )
    kmi = km.keymap_items.new("object.mode_set", 'TAB', 'PRESS')
    kmi.properties.mode = 'EDIT'
    kmi.properties.toggle = True
    vanilla_fallback_keymaps.append((km, kmi))


def _purge_orphaned_horizon_keymaps():
    """Remove HC items that survived an interrupted reload or older build."""
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon if wm else None
    if kc is None or not horizon_keymap_signatures:
        return
    for keymap in kc.keymaps:
        for kmi in list(keymap.keymap_items):
            if _keymap_signature(keymap, kmi) in horizon_keymap_signatures:
                try:
                    keymap.keymap_items.remove(kmi)
                except (ReferenceError, RuntimeError):
                    pass

def kmi_props_setattr(kmi_props, attr, value):
    try:
        setattr(kmi_props, attr, value)
    except AttributeError:
        print("Warning: property '%s' not found in keymap item '%s'" %
              (attr, kmi_props.__class__.__name__))
    except Exception as e:
        print("Warning: %r" % e)

def Keymap_Horizon():

    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc is None:
        print("Horizon Config 2.0: add-on key configuration is unavailable")
        return
    k_viewfit = 'MIDDLEMOUSE'
    k_manip = 'LEFTMOUSE'
    k_cursor = 'RIGHTMOUSE'
    k_nav = 'MIDDLEMOUSE'
    k_menu = 'SPACE'
    k_select = 'LEFTMOUSE'


    def Global_Keys():

        kmi = _new_kmi(km, "screen.userpref_show","TAB","PRESS", ctrl=True)
        # kmi = _new_kmi(km, "view3d.smart_scale","S","PRESS")
        kmi = _new_kmi(km, "wm.window_fullscreen_toggle","F11","PRESS")
        kmi = _new_kmi(km, 'screen.animation_play', 'PERIOD', 'PRESS')
        #kmi = _new_kmi(km, "view3d.hp_duplicate_move","D","PRESS", shift=True)
#        kmi = _new_kmi(km, "wm.call_menu_pie","SPACE","PRESS", shift=True).properties.name='HP_MT_popup_uber'
#        kmi = _new_kmi(km, "wm.call_menu_pie","Z","PRESS").properties.name='HP_MT_popup_uber'
        kmi = _new_kmi(km, "popup.hp_properties", 'V',"PRESS", ctrl=True, shift=True)
        kmi = _new_kmi(km, "popup.hp_materials", 'V',"PRESS", shift=True)
    # kmi = _new_kmi(km, 'gpencil.blank_frame_add', 'B', 'PRESS', key_modifier='FOUR')
# "ACCENT_GRAVE"
#Window
    km = kc.keymaps.new('Window', space_type='EMPTY', region_type='WINDOW', modal=False)
    Global_Keys()
    kmi = _new_kmi(km, 'object.hide_view_set', 'H', 'PRESS')
    kmi = _new_kmi(km, 'wm.save_homefile', 'U', 'PRESS', ctrl=True)
    kmi = _new_kmi(km, 'transform.translate', 'SPACE', 'PRESS')
    #kmi = _new_kmi(km, 'object.modal_translate', 'SPACE', 'PRESS')

    kmi = _new_kmi(km, 'view3d.smart_delete', 'X', 'PRESS')
    kmi = _new_kmi(km, 'mesh.dissolve_mode', 'X', 'PRESS',ctrl=True)
#kmi = _new_kmi(km, 'transform.resize', 'SPACE', 'PRESS', alt=True)
    kmi = _new_kmi(km, 'transform.rotate', 'C', 'PRESS')
    kmi = _new_kmi(km, "wm.call_menu_pie", k_menu,"PRESS",ctrl=True ,shift=True, alt=True).properties.name="HP_MT_pie_areas"
    kmi = _new_kmi(km, "wm.call_menu_pie", 'TAB',"PRESS",shift=True).properties.name="HP_MT_pie_areas"
    kmi = _new_kmi(km, "wm.revert_without_prompt","N","PRESS", alt=True)
    kmi = _new_kmi(km, "screen.redo_last","D","PRESS")
    if _operator_exists('wm.console_toggle'):
        kmi = _new_kmi(km, 'wm.console_toggle', 'TAB', 'PRESS', ctrl=True, shift=True)

    kmi = _new_kmi(km, "wm.call_menu_pie","S","PRESS", ctrl=True).properties.name="HP_MT_pie_save"
    kmi = _new_kmi(km, "wm.call_menu_pie","S","PRESS", ctrl=True, shift=True).properties.name="HP_MT_pie_importexport"
    kmi = _new_kmi(km, 'script.reload', 'U', 'PRESS', shift=True)
    kmi = _new_kmi(km, "screen.repeat_last","THREE","PRESS", ctrl=True, shift=True)
    kmi = _new_kmi(km, "ed.undo","TWO","PRESS", ctrl=True, shift=True)
    kmi = _new_kmi(km, 'screen.frame_jump', 'PERIOD', 'PRESS', shift=True)



# Map Image
    km = kc.keymaps.new('Image', space_type='IMAGE_EDITOR', region_type='WINDOW', modal=False)
    Global_Keys()
    kmi = _new_kmi(km, 'image.view_all', k_viewfit, 'PRESS', ctrl=True, shift=True)
    kmi_props_setattr(kmi.properties, 'fit_view', True)
    kmi = _new_kmi(km, 'image.view_pan', k_nav, 'PRESS', shift=True)
    kmi = _new_kmi(km, 'image.view_zoom', k_nav, 'PRESS', ctrl=True)

# Map Node Editor
    km = kc.keymaps.new('Node Editor', space_type='NODE_EDITOR', region_type='WINDOW', modal=False)
    kmi = _new_kmi(km, 'node.view_selected', k_viewfit, 'PRESS', ctrl=True, shift=True)
# Map View2D
    km = kc.keymaps.new('View2D', space_type='EMPTY', region_type='WINDOW', modal=False)

# Map Animation
    km = kc.keymaps.new('Animation', space_type='EMPTY', region_type='WINDOW', modal=False)
    kmi = _new_kmi(km, 'anim.change_frame', k_nav, 'PRESS')
    kmi = _new_kmi(km, 'anim.change_frame', k_select, 'PRESS', alt = True)
    kmi = _new_kmi(km, 'action.select_box', 'LEFTMOUSE', 'CLICK_DRAG', shift=True)
    kmi_props_setattr(kmi.properties, 'mode', 'ADD')
    kmi = _new_kmi(km, 'action.select_box', 'LEFTMOUSE', 'CLICK_DRAG', ctrl=True)
    kmi_props_setattr(kmi.properties, 'mode', 'SUB')
    kmi = _new_kmi(km, 'action.select_box', 'LEFTMOUSE', 'CLICK_DRAG')
    kmi_props_setattr(kmi.properties, 'mode', 'SET')
# Map DOPESHEET_EDITOR
    km = kc.keymaps.new('Dopesheet', space_type='DOPESHEET_EDITOR', region_type='WINDOW', modal=False)
    Global_Keys()
    #Dopesheet transform fix
    kmi = _new_kmi(km, 'transform.transform', 'SPACE', 'PRESS', repeat=True)
    kmi.properties.mode = 'TIME_TRANSLATE'
    print(f"Created keymap: {km.name}")
    print(f"Added keymap item: {kmi.idname} ({kmi.type})")


    kmi = _new_kmi(km, 'anim.change_frame', k_select, 'PRESS', alt = True)
    kmi = _new_kmi(km, 'anim.start_frame_set', 'S', 'PRESS')
    kmi = _new_kmi(km, 'anim.end_frame_set', 'E', 'PRESS')
    kmi = _new_kmi(km, 'action.view_all', k_viewfit, 'PRESS', ctrl=True, shift=True)

# Map Graph Editor
    km = kc.keymaps.new('Graph Editor', space_type='GRAPH_EDITOR', region_type='WINDOW', modal=False)
    Global_Keys()
    kmi = _new_kmi(km, 'graph.view_selected', k_viewfit, 'PRESS', ctrl=True, shift=True)
    kmi = _new_kmi(km, 'graph.cursor_set', k_select, 'PRESS', alt = True)
    kmi = _new_kmi(km, 'graph.select_box', 'LEFTMOUSE', 'CLICK_DRAG', shift=True)
    kmi_props_setattr(kmi.properties, 'mode', 'ADD')
    kmi = _new_kmi(km, 'graph.select_box', 'LEFTMOUSE', 'CLICK_DRAG', ctrl=True)
    kmi_props_setattr(kmi.properties, 'mode', 'SUB')
    kmi = _new_kmi(km, 'graph.select_box', 'LEFTMOUSE', 'CLICK_DRAG')
    kmi_props_setattr(kmi.properties, 'mode', 'SET')
# Map UV Editor
    km = kc.keymaps.new('UV Editor', space_type='EMPTY', region_type='WINDOW', modal=False)
    Global_Keys()
    kmi = _new_kmi(km, 'image.view_selected', k_viewfit, 'PRESS', ctrl=True, shift=True)
    kmi = _new_kmi(km, "wm.call_menu_pie", k_menu,"PRESS",ctrl=True, alt=True).properties.name="HP_MT_pie_rotate90"
# Map Mask Editing
#    km = kc.keymaps.new('Mask Editing', space_type='EMPTY', region_type='WINDOW', modal=False)
#3D View
    km = kc.keymaps.new('3D View', space_type='VIEW_3D', region_type='WINDOW', modal=False)
    Global_Keys()
    kmi = _new_kmi(km, "wm.call_menu", 'A', 'PRESS', ctrl=True, shift=True).properties.name = "VIEW3D_MT_add"
    kmi = _new_kmi(km, "view3d.smart_scale","S","PRESS")
    kmi = _new_kmi(km, "view3d.hp_draw","D","PRESS", ctrl=True)
#    kmi = _new_kmi(km, 'view3d.render_border', 'B', 'PRESS', shift=True)
#    kmi = _new_kmi(km, 'view3d.clear_render_border', 'B', 'PRESS', shift=True, ctrl=True)
    kmi = _new_kmi(km, 'mesh.hp_extrude', 'SPACE', 'PRESS', shift=True)

    kmi = _new_kmi(km, 'view3d.render_border', 'B', 'PRESS',shift=True, ctrl=True)
    kmi = _new_kmi(km, "wm.call_menu_pie", k_menu,"PRESS",ctrl=True ,shift=True, alt=True).properties.name="HP_MT_pie_areas"
    kmi = _new_kmi(km, 'view3d.view_selected', k_nav, 'PRESS', ctrl=True, shift=True)
    kmi = _new_kmi(km, 'view3d.move', k_nav, 'PRESS', shift=True)
    kmi = _new_kmi(km, 'view3d.zoom', k_nav, 'PRESS', ctrl=True)
    kmi = _new_kmi(km, 'view3d.rotate', k_nav, 'PRESS')
    kmi = _new_kmi(km, 'gizmogroup.gizmo_tweak', k_manip, 'PRESS')
    kmi = _new_kmi(km, "wm.call_menu_pie", k_menu,"PRESS",ctrl=True).properties.name="HP_MT_pie_select"
    kmi = _new_kmi(km, "wm.call_menu_pie", k_menu, 'PRESS',ctrl=True, alt=True).properties.name="HP_MT_pie_rotate90"
    kmi = _new_kmi(km, "wm.call_menu_pie", 'V', 'PRESS').properties.name="HP_MT_pie_view"
    kmi = _new_kmi(km, 'wm.call_menu_pie', k_menu,'PRESS',ctrl=True, shift=True).properties.name="HP_MT_pie_pivots"
    kmi = _new_kmi(km, "wm.call_menu_pie","Z","PRESS").properties.name="HP_MT_pie_shading"
    kmi = _new_kmi(km, "wm.call_menu_pie","D","PRESS",ctrl=True, shift=True).properties.name="HP_MT_pie_specials"
    kmi = _new_kmi(km, "wm.call_menu_pie","ONE","PRESS").properties.name="HP_MT_pie_modifiers"
    kmi = _new_kmi(km, "wm.call_menu_pie","X","PRESS",shift=True).properties.name="HP_MT_pie_symmetry"
    kmi = _new_kmi(km, 'wm.call_menu_pie', 'B', 'PRESS',ctrl=True).properties.name="HP_MT_pie_boolean"
    kmi = _new_kmi(km, "screen.repeat_last","Z","PRESS",ctrl=True, alt=True)
    kmi = _new_kmi(km, "screen.repeat_last","WHEELINMOUSE","PRESS",ctrl=True, shift=True, alt=True)
    kmi = _new_kmi(km, "ed.undo","WHEELOUTMOUSE","PRESS",ctrl=True, shift=True, alt=True)
    if _operator_exists("view3d.screencast_keys"):
        kmi = _new_kmi(km, "view3d.screencast_keys","U","PRESS",alt=True)
    kmi = _new_kmi(km, 'view3d.select_lasso', 'LEFTMOUSE', 'CLICK_DRAG', shift=True, ctrl=True)
    kmi = _new_kmi(km, 'view3d.select_box', 'LEFTMOUSE', 'CLICK_DRAG',ctrl=True).properties.mode='SUB'
    kmi = _new_kmi(km, 'view3d.select_box', 'LEFTMOUSE', 'CLICK_DRAG',shift=True).properties.mode='ADD'
    kmi = _new_kmi(km, 'view3d.select_box', 'LEFTMOUSE', 'CLICK_DRAG').properties.mode='SET'
    kmi = _new_kmi(km, "wm.search_menu","FIVE","PRESS")
    kmi = _new_kmi(km, "view3d.subdivision_toggle","TAB","PRESS")
    # kmi = _new_kmi(km, "view3d.smart_snap_cursor","RIGHTMOUSE","PRESS",ctrl=True)
    kmi = _new_kmi(km, "view3d.smart_snap_origin","RIGHTMOUSE","PRESS",ctrl=True, shift=True)
    kmi = _new_kmi(km, "view3d.smart_snap_cursor","RIGHTMOUSE","PRESS",ctrl=True)
    kmi = _new_kmi(km, "view3d.smart_snap_origin_collection","RIGHTMOUSE","PRESS",ctrl=True, shift=True, alt=True)


#Mesh
    km = kc.keymaps.new(name='Mesh')
    Global_Keys()
    # Double move operator
    #kmi = _new_kmi(km, "wm.modal_move_operator", 'SPACE', 'PRESS')
    #kmi = _new_kmi(km, 'wm.toolbar', 'SPACE', 'PRESS')
    kmi = _new_kmi(km, 'view3d.render_border', 'Z', 'PRESS', shift=True)
    # kmi = _new_kmi(km, 'view3d.clear_render_border', 'Z', 'PRESS', shift=True, ctrl=True)
    kmi = _new_kmi(km, "mesh.dupli_extrude_cursor", 'E', 'PRESS')
    kmi = _new_kmi(km, "transform.edge_bevelweight", 'E', 'PRESS', ctrl=True, shift=True)
    #kmi = _new_kmi(km, 'transform.translate', 'LEFTMOUSE', 'CLICK_DRAG')
    kmi = _new_kmi(km, 'view3d.select_through_border', 'LEFTMOUSE', 'CLICK_DRAG')
    kmi = _new_kmi(km, 'view3d.select_through_border_add', 'LEFTMOUSE', 'CLICK_DRAG',shift=True)
    kmi = _new_kmi(km, 'view3d.select_through_border_sub', 'LEFTMOUSE', 'CLICK_DRAG',ctrl=True)
    kmi = _new_kmi(km, "wm.call_menu_pie","A","PRESS", shift=True).properties.name="HP_MT_pie_add"
    kmi = _new_kmi(km, "wm.call_menu","W","PRESS").properties.name="VIEW3D_MT_edit_mesh_context_menu"
    kmi = _new_kmi(km, "view3d.subdivision_toggle","TAB","PRESS")
#    kmi = _new_kmi(km, 'mesh.select_all', k_select, 'CLICK', ctrl=True)
#    kmi_props_setattr(kmi.properties, 'action', 'INVERT')
    kmi = _new_kmi(km, 'mesh.shortest_path_pick', 'LEFTMOUSE', 'CLICK',ctrl=True, shift=True).properties.use_fill=True
    kmi = _new_kmi(km, 'mesh.select_linked', k_select, 'DOUBLE_CLICK')
    kmi_props_setattr(kmi.properties, 'delimit', {'SEAM'})
    kmi = _new_kmi(km, 'mesh.select_linked', k_select, 'DOUBLE_CLICK', shift=True)
    kmi_props_setattr(kmi.properties, 'delimit', {'SEAM'})
    kmi = _new_kmi(km, 'mesh.select_more', 'WHEELINMOUSE', 'PRESS',ctrl=True, shift=True)
    kmi = _new_kmi(km, 'mesh.select_less', 'WHEELOUTMOUSE', 'PRESS',ctrl=True, shift=True)
    kmi = _new_kmi(km, 'mesh.select_more', 'Z', 'PRESS',alt=True)
    kmi = _new_kmi(km, 'mesh.select_next_item', 'WHEELINMOUSE', 'PRESS', shift=True)
    kmi = _new_kmi(km, 'mesh.select_next_item', 'Z', 'PRESS', shift=True)
    kmi = _new_kmi(km, 'mesh.select_prev_item', 'WHEELOUTMOUSE', 'PRESS', shift=True)
    kmi = _new_kmi(km, 'mesh.edgering_select', k_select, 'DOUBLE_CLICK', alt=True).properties.extend = False
    kmi = _new_kmi(km, 'mesh.select_edge_loop_multi', k_select, 'DOUBLE_CLICK', alt=True, shift=True)
    kmi = _new_kmi(km, 'mesh.loop_select', k_select, 'PRESS', alt=True, shift=True).properties.extend = True
    kmi = _new_kmi(km, 'mesh.loop_select', k_select, 'PRESS', alt=True).properties.extend = False
    kmi = _new_kmi(km, 'mesh.normals_make_consistent', 'N', 'PRESS', ctrl=True).properties.inside = False
    # The former GPENCIL_PIE_tool_palette was removed with Grease Pencil 3.
    # Its replacement belongs to the dedicated Grease Pencil phase.
    kmi = _new_kmi(km, "mesh.select_prev_item","TWO","PRESS")
    kmi = _new_kmi(km, "mesh.select_next_item","THREE","PRESS")
    kmi = _new_kmi(km, "mesh.select_less","TWO","PRESS", ctrl=True)
    kmi = _new_kmi(km, "mesh.select_more","THREE","PRESS", ctrl=True)
    kmi = _new_kmi(km, "mesh.inset", "SPACE", "PRESS", alt=True)
    kmi = _new_kmi(km, "mesh.push_and_slide","G","PRESS", shift=True)
#    kmi_props_setattr(kmi.properties, 'use_even_offset', True)
    kmi = _new_kmi(km, 'object.separate_and_select', 'P', 'PRESS')
    kmi = _new_kmi(km, 'mesh.bridge_edge_loops', 'B', 'PRESS', shift=True)
    kmi = _new_kmi(km, 'mesh.bridge_edge_loops', 'B', 'PRESS', ctrl=True, shift=True).properties.number_cuts = 12
    kmi = _new_kmi(km, 'transform.edge_bevelweight','B', 'PRESS', alt=True).properties.value = 1
    kmi = _new_kmi(km, 'view3d.smart_bevel','B', 'PRESS')
    kmi = _new_kmi(km, 'mesh.merge', 'J', 'PRESS', ctrl=True)
    kmi_props_setattr(kmi.properties, 'type', 'LAST')
    kmi = _new_kmi(km, 'mesh.hp_unhide', 'H', 'PRESS', ctrl=True, shift=True)
#Grease Pencil
    km = kc.keymaps.new('Grease Pencil', space_type='EMPTY', region_type='WINDOW', modal=False)
    Global_Keys()
    kmi = _new_kmi(km, 'grease_pencil.select_linked', k_select, 'DOUBLE_CLICK')
    kmi = _new_kmi(km, 'grease_pencil.select_linked', k_select, 'DOUBLE_CLICK', shift=True)
    # kmi = _new_kmi(km, 'gpencil.select_box', k_select,'CLICK_DRAG')
    # kmi_props_setattr(kmi.properties, 'mode', 'SET')
    # kmi_props_setattr(kmi.properties, 'wait_for_input',False)
    # kmi = _new_kmi(km, 'gpencil.select_box', k_select,'CLICK_DRAG', ctrl=True)
    # kmi_props_setattr(kmi.properties, 'mode', 'SUB')
    # kmi_props_setattr(kmi.properties, 'wait_for_input',False)
    # kmi = _new_kmi(km, 'gpencil.select_box', k_select, 'CLICK_DRAG', shift=True)
    # kmi_props_setattr(kmi.properties, 'mode', 'ADD')
    # kmi_props_setattr(kmi.properties, 'wait_for_input',False)
#Image Paint
    km = kc.keymaps.new(name='Image Paint')
    kmi = _new_kmi(km, 'paint.sample_color', 'S', 'PRESS')
#Object Mode
    km = kc.keymaps.new(name='Object Mode')
    Global_Keys()
    # kmi = _new_kmi(km, 'view3d.smart_bevel','B', 'PRESS')
    #kmi = _new_kmi(km, 'object.select_all', k_select, 'CLICK_DRAG')
    #kmi_props_setattr(kmi.properties, 'action', 'DESELECT')
#    kmi = _new_kmi(km, 'object.select_all', k_select, 'CLICK', ctrl=True)
#    kmi_props_setattr(kmi.properties, 'action', 'INVERT')
    kmi = _new_kmi(km, 'object.hide_view_clear', 'H', 'PRESS', ctrl=True, shift=True)

#Sculpt Mode
    km = kc.keymaps.new(name='Sculpt')
    Global_Keys()
    kmi = _new_kmi(km, "wm.call_menu_pie", 'V', 'PRESS').properties.name="HP_MT_pie_view"

# Map Curve
    km = kc.keymaps.new('Curve', space_type='EMPTY', region_type='WINDOW', modal=False)
    Global_Keys()
    kmi = _new_kmi(km, 'curve.select_linked', k_select, 'DOUBLE_CLICK', shift=True)
    kmi = _new_kmi(km, 'curve.select_linked_pick', k_select, 'DOUBLE_CLICK')
    kmi = _new_kmi(km, 'curve.reveal', 'H', 'PRESS', ctrl=True, shift=True)
    kmi = _new_kmi(km, 'curve.shortest_path_pick', k_select, 'PRESS', ctrl=True, shift=True)
    kmi = _new_kmi(km, 'curve.draw', 'LEFTMOUSE', 'PRESS', alt=True)

# Outliner
    km = kc.keymaps.new('Outliner', space_type='OUTLINER', region_type='WINDOW', modal=False)
    kmi = _new_kmi(km, 'outliner.show_active', k_nav, 'PRESS', ctrl=True, shift=True)
    Global_Keys()

    kmi = _new_kmi(km, 'wm.delete_without_prompt', 'X', 'PRESS')

# Lattice
    km = kc.keymaps.new(name='Lattice')
    Global_Keys()
    kmi = _new_kmi(km, 'view3d.select_box', 'LEFTMOUSE', 'CLICK_DRAG', shift=False, ctrl=False)
    kmi = _new_kmi(km, 'view3d.select_box', 'LEFTMOUSE', 'CLICK_DRAG', shift=True, ctrl=False)
    kmi_props_setattr(kmi.properties, 'mode', 'ADD')
    kmi = _new_kmi(km, 'view3d.select_box', 'LEFTMOUSE', 'CLICK_DRAG', shift=False, ctrl=True)
    kmi_props_setattr(kmi.properties, 'mode', 'SUB')




# Functions to disable conflicting default bindings while remembering their
# previous state. This keeps enable/disable and Reload Scripts reversible.
def _default_keyconfig():
    wm = bpy.context.window_manager
    return wm.keyconfigs.get('Blender') if wm else None


def _disable_and_remember(kmi):
    if kmi is None or not kmi.active:
        return False
    disabled_default_keymaps.append((kmi, True))
    kmi.active = False
    return True


def disable_default_kmi(km=None, idname=None, retries=1):
    if not (km and idname):
        return False
    kc = _default_keyconfig()
    keymap = kc.keymaps.get(km) if kc else None
    if keymap is None:
        return False
    for kmi in keymap.keymap_items:
        if kmi.idname == idname:
            return _disable_and_remember(kmi)
    return False


def disable_specific_kmi(km=None, idname=None, type=None, value=None,
                         shift=None, ctrl=None, alt=None, retries=1):
    if not (km and idname):
        return False
    kc = _default_keyconfig()
    keymap = kc.keymaps.get(km) if kc else None
    if keymap is None:
        return False
    for kmi in keymap.keymap_items:
        matches = (
            kmi.idname == idname and
            (type is None or kmi.type == type) and
            (value is None or kmi.value == value) and
            (shift is None or kmi.shift == shift) and
            (ctrl is None or kmi.ctrl == ctrl) and
            (alt is None or kmi.alt == alt)
        )
        if matches:
            return _disable_and_remember(kmi)
    return False

def get_active_kmi(space: str, **kwargs) -> bpy.types.KeyMapItem:
    kc = bpy.context.window_manager.keyconfigs.active
    if kc is None:
        return None
    km = kc.keymaps.get(space)
    if km:
        for kmi in km.keymap_items:
            for key, val in kwargs.items():
                if getattr(kmi, key) != val and val is not None:
                    break
            else:
                return kmi




def enable_horizon_keymaps():
    if addon_keymaps:
        bpy.app.driver_namespace['HC_HOTKEYS_ENABLED'] = True
        return

    _remove_vanilla_fallback_keymaps()
    _purge_orphaned_horizon_keymaps()
    Keymap_Horizon()
    horizon_keymap_signatures.update(
        _keymap_signature(keymap, kmi) for keymap, kmi in addon_keymaps
    )
    disable_default_kmi('Object Mode', 'transform.resize')
    disable_specific_kmi('Object Mode', 'transform.translate','LEFTMOUSE','CLICK_DRAG',False,False,False)
    disable_default_kmi('Object Mode', 'object.delete')
    disable_default_kmi('Object Mode', 'screen.animation_play')

    disable_specific_kmi('Curve', 'transform.translate','LEFTMOUSE','CLICK_DRAG',False,False,False)
    disable_specific_kmi('Curves', 'transform.translate','LEFTMOUSE','CLICK_DRAG',False,False,False)
    disable_specific_kmi('Grease Pencil Edit Mode', 'wm.call_menu','X','PRESS',False,False,False)



    disable_default_kmi('Object Mode', 'object.delete')

    disable_default_kmi('Window', 'screen.animation_play')

    disable_default_kmi('Frames', 'screen.animation_play')

    disable_default_kmi('Mesh', 'wm.call_menu')

    disable_specific_kmi('Sculpt', 'paint.brush_select','V','PRESS',False,False,False)
    
    disable_specific_kmi('3D View Tool: Select Box', 'view3d.select_box','LEFTMOUSE','CLICK_DRAG',False,False,False)
    disable_specific_kmi('3D View Tool: Select Box', 'view3d.select_box','LEFTMOUSE','CLICK_DRAG',True,False,False)
    disable_specific_kmi('3D View Tool: Select Box', 'view3d.select_box','LEFTMOUSE','CLICK_DRAG',False,True,False)
    disable_specific_kmi('3D View Tool: Select Box', 'view3d.select_box','LEFTMOUSE','CLICK_DRAG',True,True,False)
    
    
    kmi = get_active_kmi("3D View Tool: Move",
                         idname="transform.translate",
                         type='LEFTMOUSE',
                         value='CLICK_DRAG',
                         shift=False,
                         ctrl=False,
                         alt=False)
    _disable_and_remember(kmi)

    kmi = get_active_kmi("Pose",
                         idname="transform.translate",
                         type='LEFTMOUSE',
                         value='CLICK_DRAG',
                         shift=False,
                         ctrl=False,
                         alt=False)
    _disable_and_remember(kmi)

    kmi = get_active_kmi("Mesh",
                         idname="wm.call_menu",
                         type='X',
                         shift=False,
                         ctrl=False,
                         alt=False)
    _disable_and_remember(kmi)
    kmi = get_active_kmi("Grease Pencil Edit Mode",
                         idname="wm.call_menu",
                         type='X',
                         shift=False,
                         ctrl=False,
                         alt=False)
    _disable_and_remember(kmi)
    kmi = get_active_kmi("Frames",
                         idname="screen.animation_play",
                         type='SPACE',
                         shift=True,
                         ctrl=True,
                         alt=False)
    _disable_and_remember(kmi)

    bpy.app.driver_namespace['HC_HOTKEYS_ENABLED'] = True


def disable_horizon_keymaps(install_vanilla_fallback=True):
    for keymap, kmi in reversed(addon_keymaps):
        try:
            keymap.keymap_items.remove(kmi)
        except (ReferenceError, RuntimeError):
            pass
    addon_keymaps.clear()
    _purge_orphaned_horizon_keymaps()

    for kmi, was_active in reversed(disabled_default_keymaps):
        try:
            kmi.active = was_active
        except (ReferenceError, RuntimeError):
            pass
    disabled_default_keymaps.clear()

    if install_vanilla_fallback:
        _install_vanilla_fallback_keymaps()
    else:
        _remove_vanilla_fallback_keymaps()

    bpy.app.driver_namespace['HC_HOTKEYS_ENABLED'] = False


class HC_OT_toggle_hotkeys(bpy.types.Operator):
    bl_idname = "wm.hc_toggle_hotkeys"
    bl_label = "Toggle Horizon / Vanilla Hotkeys"
    bl_description = (
        "Switch between Horizon Config keymaps and Blender's original keymaps"
    )

    def execute(self, context):
        if addon_keymaps:
            disable_horizon_keymaps()
            self.report({'INFO'}, "Vanilla Blender hotkeys enabled")
        else:
            enable_horizon_keymaps()
            self.report({'INFO'}, "Horizon Config 2.0 hotkeys enabled")
        return {'FINISHED'}


def register():
    # Clean up keys left by an in-session module reload before rebuilding.
    disable_horizon_keymaps(install_vanilla_fallback=False)
    try:
        bpy.utils.register_class(HC_OT_toggle_hotkeys)
    except RuntimeError:
        pass
    enable_horizon_keymaps()


def unregister():
    disable_horizon_keymaps(install_vanilla_fallback=False)
    try:
        bpy.utils.unregister_class(HC_OT_toggle_hotkeys)
    except RuntimeError:
        pass
    bpy.app.driver_namespace.pop('HC_HOTKEYS_ENABLED', None)

if __name__ == "__main__":
    register()
