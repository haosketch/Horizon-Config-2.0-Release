param(
    [string]$BlenderDir = ""
)

$ErrorActionPreference = "Stop"
$packageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$sourcePortable = Join-Path $packageRoot "portable"

if (-not (Test-Path -LiteralPath $sourcePortable -PathType Container)) {
    throw "The package payload was not found: $sourcePortable"
}

if ([string]::IsNullOrWhiteSpace($BlenderDir)) {
    if (Test-Path -LiteralPath (Join-Path $packageRoot "blender.exe") -PathType Leaf) {
        $BlenderDir = $packageRoot
    }
    else {
        $BlenderDir = Read-Host "Paste the folder containing Blender 5.2 blender.exe"
    }
}

$BlenderDir = [IO.Path]::GetFullPath($BlenderDir.Trim('"'))
$blenderExe = Join-Path $BlenderDir "blender.exe"
if (-not (Test-Path -LiteralPath $blenderExe -PathType Leaf)) {
    throw "blender.exe was not found in: $BlenderDir"
}

$versionText = & $blenderExe --version 2>&1 | Select-Object -First 1
if ($versionText -notmatch '^Blender 5\.2') {
    throw "Horizon Config 2.1 BETA targets Blender 5.2. Found: $versionText"
}

$targetPortable = Join-Path $BlenderDir "portable"
$sourceFull = [IO.Path]::GetFullPath($sourcePortable).TrimEnd('\')
$targetFull = [IO.Path]::GetFullPath($targetPortable).TrimEnd('\')

# Startup modules changed ownership during development. Remove only generated
# Python bytecode so Blender cannot reuse a stale cached module after update.
# This must run even when the package was extracted directly beside blender.exe.
$startupCache = Join-Path $targetPortable "scripts\startup\__pycache__"
if (Test-Path -LiteralPath $startupCache -PathType Container) {
    Remove-Item -LiteralPath $startupCache -Recurse -Force
}

if ($sourceFull -eq $targetFull) {
    Write-Host "Horizon Config 2.1 BETA is already in the Blender portable folder." -ForegroundColor Green
    Write-Host "Cleared cached startup bytecode." -ForegroundColor Green
    Write-Host "Launch: $blenderExe"
    exit 0
}

$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backupRoot = Join-Path $BlenderDir "Horizon-Config-backup-$stamp"
$backedUp = $false

$payloadFiles = Get-ChildItem -LiteralPath $sourcePortable -Recurse -File
foreach ($sourceFile in $payloadFiles) {
    $relativePath = $sourceFile.FullName.Substring($sourcePortable.Length).TrimStart('\')
    $targetFile = Join-Path $targetPortable $relativePath
    if (Test-Path -LiteralPath $targetFile -PathType Leaf) {
        $backupFile = Join-Path (Join-Path $backupRoot "portable") $relativePath
        $backupParent = Split-Path -Parent $backupFile
        New-Item -ItemType Directory -Path $backupParent -Force | Out-Null
        Copy-Item -LiteralPath $targetFile -Destination $backupFile -Force
        $backedUp = $true
    }
}

foreach ($sourceFile in $payloadFiles) {
    $relativePath = $sourceFile.FullName.Substring($sourcePortable.Length).TrimStart('\')
    $targetFile = Join-Path $targetPortable $relativePath
    $targetParent = Split-Path -Parent $targetFile
    New-Item -ItemType Directory -Path $targetParent -Force | Out-Null
    Copy-Item -LiteralPath $sourceFile.FullName -Destination $targetFile -Force
}

Write-Host "Horizon Config 2.1 BETA for Blender 5.2 installed." -ForegroundColor Green
Write-Host "Launch: $blenderExe"
if ($backedUp) {
    Write-Host "Previous overwritten files were backed up to: $backupRoot" -ForegroundColor Yellow
}
