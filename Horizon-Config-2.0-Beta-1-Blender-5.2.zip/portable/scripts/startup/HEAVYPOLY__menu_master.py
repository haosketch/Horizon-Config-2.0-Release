import bpy
import random
from bpy.props import *
from bpy_extras.node_utils import find_node_input


class HP_MT_popup_uber(bpy.types.Menu): 
    bl_label = "Horizon Config 2.0 Uber Popup"
    type: bpy.props.StringProperty(name="Type")

    def draw(self, context):
        layout = self.layout
        layout = layout.menu_pie()
        layout.operator_context = 'INVOKE_REGION_WIN'
        #Left
        layout.operator("transform.rotate")
        #Right
        layout.operator("transform.resize", text="Scale")
        #Bottom
        layout.operator("view3d.smart_bevel", text = 'Bevel')
        #Top
        layout.operator("mesh.hp_extrude", text = 'Extrude')
        #Top Left
        layout.operator("transform.shrink_fatten",text = 'Move')
        #Top Right
        layout.operator("view3d.hp_duplicate_move", text = 'Duplicate')
        #Bottom Left
        layout.operator('popup.hp_render',text = 'Render Settings')
        #Bottom Right
        layout.operator('popup.hp_properties', text='Properties')
            

classes = (
    HP_MT_popup_uber,

)
register, unregister = bpy.utils.register_classes_factory(classes)


if __name__ == "__main__":
    register()
