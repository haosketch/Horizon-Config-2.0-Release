# Horizon Config 2.0 — Beta 1 Quick Test

Use a duplicate of important `.blend` files while evaluating the Beta.

## Startup

- Launch Blender 5.2 twice and confirm no Python traceback appears.
- Confirm the `N` sidebar contains the **HC 2.0** tab.
- Confirm Render Properties shows Bloom enabled at `0.05`.

## Mapping switch

- In HC mapping, press `Tab` and confirm subdivision toggles.
- Switch to Vanilla mapping, move the pointer over the main viewport, press
  `Tab`, and confirm Object/Edit mode toggles.
- Switch back to HC and repeat once to check that shortcuts do not duplicate.

## Modeling essentials

- Open the main HC pie menus in Object and Edit mode.
- Test Smart Scale, Smart Bevel, Smart Delete, Flip, Flatten, Rotate 90, Mirror,
  Symmetry, Unhide, and Origin to Bottom.
- Test Shade Smooth on standard and subdivided objects.
- Test Duplicate Radial from Front, Side, and Top orthographic views.
- Test Shift+V material creation and slot assignment.
- Test Boolean creation, cutter visibility, and global enable/disable.
- Test the HC Outline toggle from the `1` modifier pie.

## Reporting a problem

Include the Blender version, operating system, mapping state, Object/Edit mode,
exact key sequence, and any traceback. A short screen recording is ideal for
interaction problems.
