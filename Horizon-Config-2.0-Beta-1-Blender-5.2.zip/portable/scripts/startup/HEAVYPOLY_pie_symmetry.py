bl_info = {
    "name": "Pie Symmetry",
    "description": "Symmetry and Mirroring",
    "author": "Vaughan Ling",
    "version": (1, 1, 0),
    "blender": (5, 2, 0),
    "category": "Pie Menu"
    }

import bpy
import bmesh
from bpy.types import Menu

# symmetrize, mirror and mirror modifier

class HP_MT_pie_symmetry(Menu):
    bl_label = "Symmetry"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        # left
        pie.operator("mesh.symmetrize_select_all", text="X").direction = 'POSITIVE_X'
        # right
        pie.operator("mesh.symmetrize_select_all", text="X").direction = 'NEGATIVE_X'
        # bottom
        pie.operator("mesh.symmetrize_select_all", text="Z").direction = 'POSITIVE_Z'
        # top
        pie.operator("mesh.symmetrize_select_all", text="Z").direction = 'NEGATIVE_Z'
        # topleft
        pie.operator("mesh.symmetrize_select_all", text="Y").direction = 'NEGATIVE_Y'
        # topright
        pie.operator("view3d.mirror_toggle", text="Live Mirror").type = 'Mirror Base'
        pie.operator("view3d.mirror_toggle", text="Live Mirror Local").type = 'Mirror Local'
        # bottomleft

#       split = pie.split()
#       col = split.column()
#       col.prop(bpy.context.object.modifiers['Mirror Base'], "use_clip", text="Clip at Center")
        pie.operator('view3d.mirror_clip_toggle', text='Center Clipping')
#       col.prop(bpy.context.object.modifiers['Mirror Base'], "mirror_object", text="")

        # bottomright
#       pie.operator("mesh.symmetrize_select_all", text="Y").direction = 'POSITIVE_Y'





class HP_OT_symmetrize_select_all(bpy.types.Operator):
    bl_idname = "mesh.symmetrize_select_all"
    bl_label = ""
    bl_options = {'REGISTER', 'UNDO'}
    direction: bpy.props.StringProperty(name="Direction")

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def invoke(self, context, event):
        obj = context.active_object
        axis = self.direction[-1]

        if obj.mode == 'OBJECT':
            bpy.ops.object.duplicate(linked=True)
            value = tuple(-1.0 if candidate == axis else 1.0 for candidate in 'XYZ')
            constraint = tuple(candidate == axis for candidate in 'XYZ')
            bpy.ops.transform.resize(
                value=value,
                constraint_axis=constraint,
                orient_type='GLOBAL',
            )
        elif obj.mode == 'EDIT' and obj.type == 'MESH':
            if event.ctrl:
                bpy.ops.mesh.symmetrize(direction=self.direction)
                return {'FINISHED'}

            bm = bmesh.from_edit_mesh(obj.data)
            selection = (
                {v.index for v in bm.verts if v.select},
                {e.index for e in bm.edges if e.select},
                {f.index for f in bm.faces if f.select},
            )
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.symmetrize(direction=self.direction)

            bm = bmesh.from_edit_mesh(obj.data)
            for element in (*bm.verts, *bm.edges, *bm.faces):
                element.select = False
            for index in selection[0]:
                if index < len(bm.verts):
                    bm.verts[index].select = True
            for index in selection[1]:
                if index < len(bm.edges):
                    bm.edges[index].select = True
            for index in selection[2]:
                if index < len(bm.faces):
                    bm.faces[index].select = True
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return {'FINISHED'}


        
class HP_OT_mirror_clip_toggle(bpy.types.Operator):
    bl_idname = "view3d.mirror_clip_toggle"
    bl_label = ""
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return any(
            hasattr(obj, 'modifiers') and any(m.type == 'MIRROR' for m in obj.modifiers)
            for obj in context.selected_objects
        )

    def execute(self, context):
        modifiers = [
            modifier
            for obj in context.selected_objects if hasattr(obj, 'modifiers')
            for modifier in obj.modifiers if modifier.type == 'MIRROR'
        ]
        enabled = not modifiers[0].use_clip
        for modifier in modifiers:
            modifier.use_clip = enabled
        return {'FINISHED'}

    def invoke(self, context, event):
        return self.execute(context)

class HP_OT_reset_center(bpy.types.Operator):
    bl_idname = "view3d.reset_center"
    bl_label = ""
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        if bpy.context.object.mode == 'EDIT':
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.transform_apply(location=True, rotation=False, scale=True)
            bpy.ops.object.mode_set(mode='EDIT')

        else:
            bpy.ops.object.transform_apply(location=True, rotation=False, scale=True)
        return {'FINISHED'}     

class HP_OT_mirror_toggle(bpy.types.Operator):
    bl_idname = "view3d.mirror_toggle"
    bl_label = ""
    bl_options = {'REGISTER', 'UNDO'}
    type: bpy.props.StringProperty(name='Type', default='Mirror Base')

    @classmethod
    def poll(cls, context):
        return any(hasattr(obj, 'modifiers') for obj in context.selected_objects)

    def execute(self, context):
        selected = [obj for obj in context.selected_objects if hasattr(obj, 'modifiers')]
        original_active = context.view_layer.objects.active
        original_mode = original_active.mode if original_active else 'OBJECT'

        if original_active and original_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        mirror_origin = bpy.data.objects.get("Mirror Origin")
        if self.type == 'Mirror Base' and mirror_origin is None:
            mirror_origin = bpy.data.objects.new("Mirror Origin", None)
            mirror_origin.empty_display_type = 'PLAIN_AXES'
            context.scene.collection.objects.link(mirror_origin)

        try:
            for obj in selected:
                modifier = obj.modifiers.get(self.type)
                if modifier is None:
                    modifier = obj.modifiers.new(self.type, 'MIRROR')
                    modifier.show_viewport = True
                    modifier.show_render = True
                    modifier.show_in_editmode = True
                    if self.type == 'Mirror Base':
                        modifier.mirror_object = mirror_origin
                    elif self.type == 'Mirror Local':
                        obj.modifiers.move(len(obj.modifiers) - 1, 0)
                else:
                    visible = not modifier.show_viewport
                    modifier.show_viewport = visible
                    modifier.show_render = visible
                    modifier.show_in_editmode = visible
        finally:
            if original_active:
                context.view_layer.objects.active = original_active
                if original_mode != 'OBJECT':
                    bpy.ops.object.mode_set(mode=original_mode)
        return {'FINISHED'}
            



            
classes = (
    HP_MT_pie_symmetry,
    HP_OT_mirror_clip_toggle,
    HP_OT_mirror_toggle,
    HP_OT_symmetrize_select_all,
    HP_OT_reset_center
)
register, unregister = bpy.utils.register_classes_factory(classes)

if __name__ == "__main__":
    register()
