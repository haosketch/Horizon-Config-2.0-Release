bl_info = {
    "name": "Pie Import Export",
    "description": "Import Export Pie",
    "author": "Vaughan Ling",
    "version": (0, 1, 0),
    "blender": (2, 79, 0),
    "location": "",
    "warning": "",
    "wiki_url": "",
    "category": "Pie Menu"
    }

import bpy
from bpy.types import (
        Menu,
        Operator,
        )
import os


def operator_exists(idname):
    try:
        category, name = idname.split('.', 1)
        getattr(getattr(bpy.ops, category), name).get_rna_type()
        return True
    except (AttributeError, KeyError):
        return False

# save import export

class HP_MT_pie_importexport(Menu):
    bl_label = "Import Export"
    
    
    


    def draw(self, context):
        #L
        layout = self.layout
        pie = layout.menu_pie()
        box = pie.split().column()
        row = box.row(align=True)
        row.scale_y=1.5

        box.operator('wm.alembic_import', text='Import Alembic')
        box.operator('import_scene.fbx', text='Import FBX')
        box.operator('wm.stl_import', text='Import STL')
        box.operator('wm.obj_import', text='Import OBJ')
        if operator_exists('import_image.to_plane'):
            box.operator('import_image.to_plane', text='Import Image Plane')
        else:
            box.label(text='Import Images as Planes not installed')
        box.operator('wm.append', text = 'Append')
        box.operator("wm.link", text = "Link")
        #R
        box = pie.split().column()
        row = box.row(align=True)
        row.scale_y=1.5
        box.operator('wm.alembic_export', text='Export Alembic')
        box.operator('export_scene.fbx', text='Export FBX')
        box.operator('wm.stl_export', text='Export STL')
        box.operator('wm.obj_export', text='Export OBJ')
        box.operator('image.save_as', text='Export Image')

        # bpy.ops.import_anim.bvh()
        # bpy.ops.import_scene.obj()
        # bpy.ops.import_curve.svg()
        # bpy.ops.import_image.to_plane()
#        bpy.ops.import_scene.autodesk_3ds()
#        bpy.ops.wm.collada_import()

#import_mesh.stl

        # box = pie.split().column()
        # row = box.row(align=True)

        # #9 - TOP - RIGHT
        # box = pie.split().column()
        # row = box.row(align=True)

def register():
    bpy.utils.register_class(HP_MT_pie_importexport)


def unregister():
    bpy.utils.unregister_class(HP_MT_pie_importexport)

if __name__ == "__main__":
    register()
