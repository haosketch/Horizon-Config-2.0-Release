# Horizon Config 2.0 — Beta 1

**Evolved from HEAVYPOLY Config. Maintained by Hao / Horizon Workshop.**

Horizon Config 2.0 is a complete Blender workflow configuration containing
preferences, a startup file, scripts, hotkeys, pie menus, modeling tools, and a
small set of viewport enhancements.

## Requirements

- Blender **5.2 LTS**
- Windows 10/11 or macOS
- A clean or backed-up Blender configuration

This Beta targets Blender 5.2 specifically. Do not install it over Blender 3.x,
4.x, 5.0, or 5.1 preferences.

## Before installing

Horizon Config includes `startup.blend` and `userpref.blend`. Installing it
therefore changes Blender's preferences, interface, theme, startup scene, and
keymaps—not only individual add-ons.

Close Blender before copying any files. For the safest test, use a separate
portable copy of Blender 5.2 rather than your everyday installation.

## Windows — portable installation (recommended)

1. Download and extract Blender 5.2's Windows ZIP from blender.org.
2. Extract the Horizon Config ZIP anywhere.
3. Double-click `Install-Horizon-Config-2.0-Portable.cmd` and, when asked,
   paste the folder containing `blender.exe`.
4. Alternatively, skip the installer and copy the included `portable` folder
   beside `blender.exe` manually.
5. Confirm this structure:

   ```text
   Blender 5.2/
   ├─ blender.exe
   └─ portable/
      ├─ config/
      └─ scripts/
   ```

6. Launch `blender.exe` from that folder.

The Windows installer validates Blender 5.2, clears stale Python bytecode, and
backs up files it replaces into a timestamped `Horizon-Config-backup-*` folder.

## Windows — regular per-user installation

Use this only if you want Horizon Config to become the configuration for your
normal Blender 5.2 installation.

1. Close Blender.
2. In File Explorer, enter `%APPDATA%\Blender Foundation\Blender\5.2\`.
3. Back up the existing `config` and `scripts` folders.
4. Copy `portable\config` and `portable\scripts` from the Horizon package into
   the `5.2` folder.
5. Launch Blender 5.2.

The final structure should contain:

```text
%APPDATA%\Blender Foundation\Blender\5.2\
├─ config\
└─ scripts\
```

## macOS — portable installation (recommended)

1. Install Blender 5.2 from the official DMG.
2. Duplicate `Blender.app` so your normal Blender installation stays intact.
   Rename the copy `Blender Horizon.app` if desired.
3. In Finder, Control-click the copied app and choose **Show Package Contents**.
4. Open `Contents/Resources`.
5. Copy the included `portable` folder into `Resources`.
6. Confirm this structure:

   ```text
   Blender Horizon.app/
   └─ Contents/
      └─ Resources/
         └─ portable/
            ├─ config/
            └─ scripts/
   ```

7. Launch the copied Blender application.

When Blender itself is replaced during an update, the `portable` folder inside
its application bundle may also be replaced. Keep the Horizon Config ZIP or a
copy of the `portable` folder for reinstalling.

## macOS — regular per-user installation

1. Close Blender.
2. In Finder choose **Go → Go to Folder…**.
3. Enter `~/Library/Application Support/Blender/5.2/`.
4. Back up the existing `config` and `scripts` folders.
5. Copy `portable/config` and `portable/scripts` from the Horizon package into
   that `5.2` folder.
6. Launch Blender 5.2.

## Confirming the installation

After Blender opens:

1. Open the 3D Viewport's `N` sidebar.
2. Confirm the **HC 2.0** tab is present.
3. Confirm the large **HC MAPPING ↔ VANILLA** control appears.
4. Open Render Properties and confirm **Horizon Config 2.0 — Render** contains
   Bloom, enabled at `0.05`.

In Vanilla mapping, `Tab` toggles Object/Edit mode. In HC mapping, `Tab`
controls subdivision.

## Updating from an earlier HC alpha

Close Blender before updating. Install Beta 1 over the same portable folder.
On Windows, use the included installer so replaced files are backed up. On
macOS, duplicate or back up the existing `portable` folder before replacing
its `config` and `scripts` contents.

## Removing Horizon Config

- Portable installation: remove or rename the `portable` folder, then relaunch
  Blender.
- Windows installer update: restore the files from the timestamped
  `Horizon-Config-backup-*` folder.
- Per-user installation: restore the `config` and `scripts` folders you backed
  up before installation.

## Beta boundaries

The core modeling workflow, hotkey lifecycle, HC/Vanilla switch, key pies,
shading, Boolean cutters, radial duplication, materials popup, outline tool,
and Bloom have been compatibility-repaired for Blender 5.2.

Grease Pencil workflow expansion and the Geometry Nodes interface redesign are
reserved for the next development phase. Historical internal `HEAVYPOLY_*`
module names and operator identifiers remain intentionally for compatibility.

See `MANIFESTO.md` for project lineage and `LICENSE.md` for licensing terms.
