bl_info = {
	"name": "Pie Rotate_90",
	"description": "Rotate 90",
	"author": "Vaughan Ling",
	"version": (1, 1, 0),
	"blender": (5, 2, 0),
	"location": "",
	"warning": "",
	"wiki_url": "",
	"category": "Pie Menu"
	}

import bpy, bmesh
from bpy.types import (
		Menu,
		Operator,
		)
import os
class HP_MT_pie_rotate90(Menu):
	bl_label = "Rotate_90"

	def draw(self, context):
		layout = self.layout
		pie = layout.menu_pie()
		# left
		pie.operator('view3d.rotate_90_and_flatten', text = 'Side', icon="CENTER_ONLY").direction = 'FX'
		# right
		pie.operator('view3d.rotate_90_and_flatten', text = 'Side', icon="FILE_REFRESH").direction = 'RX'

		pie.split()
		pie.split()

		pie.operator('view3d.rotate_90_and_flatten', text = 'Front', icon="CENTER_ONLY").direction = 'FY'

		pie.operator('view3d.rotate_90_and_flatten', text = 'Front', icon="FILE_REFRESH").direction = 'RY'

		# bottomleft
		pie.operator('view3d.rotate_90_and_flatten', text = 'Top', icon="CENTER_ONLY").direction = 'FZ'
		# bottomright
		pie.operator('view3d.rotate_90_and_flatten', text = 'Top', icon="FILE_REFRESH").direction = 'RZ'


class HP_OT_rotate_90_and_flatten(bpy.types.Operator):
	bl_idname = "view3d.rotate_90_and_flatten"
	bl_label = "Rotate 90 / Flatten"
	bl_options = {'REGISTER', 'UNDO'}
	direction: bpy.props.StringProperty(name="Direction")

	@classmethod
	def poll(cls, context):
		return context.active_object is not None

	def execute(self, context):
		obj = context.active_object
		mesh = obj.data if obj.type == 'MESH' else None
		selection = None
		pivot = context.scene.tool_settings.transform_pivot_point
		cursor_location = context.scene.cursor.location.copy()
		use_single_vertex_pivot = False

		if mesh is not None and obj.mode == 'EDIT':
			bm = bmesh.from_edit_mesh(mesh)
			selection = (
				{v.index for v in bm.verts if v.select},
				{e.index for e in bm.edges if e.select},
				{f.index for f in bm.faces if f.select},
			)
			if not any(selection):
				bpy.ops.mesh.select_all(action='SELECT')
			elif context.tool_settings.mesh_select_mode == (True, False, False) and len(selection[0]) == 1:
				use_single_vertex_pivot = True
				bpy.ops.view3d.snap_cursor_to_selected()
				context.scene.tool_settings.transform_pivot_point = 'CURSOR'
				bpy.ops.mesh.select_linked(delimit=set())

		try:
			if self.direction.startswith('R'):
				axis = self.direction[-1]
				constraint = tuple(axis == candidate for candidate in 'XYZ')
				bpy.ops.transform.rotate(
					value=1.57079632679,
					orient_axis=axis,
					orient_type='GLOBAL',
					constraint_axis=constraint,
				)
			elif self.direction.startswith('F'):
				axis = self.direction[-1]
				value = tuple(0.0 if axis == candidate else 1.0 for candidate in 'XYZ')
				constraint = tuple(axis == candidate for candidate in 'XYZ')
				bpy.ops.transform.resize(
					value=value,
					constraint_axis=constraint,
					orient_type='GLOBAL',
				)
			else:
				self.report({'ERROR'}, f"Unknown direction: {self.direction}")
				return {'CANCELLED'}
		finally:
			if use_single_vertex_pivot and mesh is not None:
				bm = bmesh.from_edit_mesh(mesh)
				for element in (*bm.verts, *bm.edges, *bm.faces):
					element.select = False
				for index in selection[0]:
					if index < len(bm.verts):
						bm.verts[index].select = True
				for index in selection[1]:
					if index < len(bm.edges):
						bm.edges[index].select = True
				for index in selection[2]:
					if index < len(bm.faces):
						bm.faces[index].select = True
				bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
				context.scene.tool_settings.transform_pivot_point = pivot
				context.scene.cursor.location = cursor_location

		return {'FINISHED'}
classes = (
	HP_MT_pie_rotate90,
	HP_OT_rotate_90_and_flatten
)
register, unregister = bpy.utils.register_classes_factory(classes)	

if __name__ == "__main__":
	register()
