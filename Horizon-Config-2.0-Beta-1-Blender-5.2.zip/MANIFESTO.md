# Horizon Config 2.0

## Evolved from HEAVYPOLY Config

HEAVYPOLY Config established a distinctive way of working in Blender: direct,
fast, spatial, and built around creative flow. Horizon Config 2.0 exists because
that interaction language remains worth preserving.

This project does not erase where it came from. It is an independent evolution
of HEAVYPOLY Config, rebuilt to repair aging code, preserve the strongest parts
of the original workflow, and carry them into current versions of Blender.

As regular compatibility maintenance for the original configuration has
slowed, Hao is taking responsibility for this new branch—testing it, refining
it with working artists, and maintaining it going forward through Horizon
Workshop.

**HEAVYPOLY reborn. Horizon Config. A familiar foundation, carried toward a
new horizon.**

### Credit

Horizon Config 2.0 is evolved from the original **HEAVYPOLY Config** created by
Vaughan Ling, with contributions from Julien Gauthier and the HEAVYPOLY
community. Their work, ideas, and years of shared development made this project
possible.

Horizon Config 2.0 is an independent continuation and is not presented as an
official HEAVYPOLY release.

### Stewardship

Maintained by **Hao / Horizon Workshop**.
