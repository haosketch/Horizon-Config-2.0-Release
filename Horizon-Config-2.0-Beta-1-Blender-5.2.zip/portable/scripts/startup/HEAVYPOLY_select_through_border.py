
bl_info = {
	"name": "Border Select Through",
	"description": "Border Select through a mesh",
	"author": ("Vaughan Ling"),
	"version": (1, 1, 0),
	"blender": (5, 2, 0),
	"location": "",
	"warning": "",
	"wiki_url": "",
	"category": "Pie Menu"
	}

import bpy
import gpu
from gpu_extras.batch import batch_for_shader


class HP_SelectThroughMixin:
	selection_mode = 'SET'
	_draw_handle = None

	@classmethod
	def poll(cls, context):
		return (
			context.area is not None and
			context.area.type == 'VIEW_3D' and
			context.region is not None and
			context.region.type == 'WINDOW' and
			context.active_object is not None and
			context.active_object.type == 'MESH' and
			context.active_object.mode == 'EDIT'
		)

	def _draw_box(self):
		x1, y1 = self._start
		x2, y2 = self._current
		shader = gpu.shader.from_builtin('UNIFORM_COLOR')
		batch = batch_for_shader(
			shader,
			'LINE_LOOP',
			{"pos": ((x1, y1, 0.0), (x2, y1, 0.0), (x2, y2, 0.0), (x1, y2, 0.0))},
		)
		gpu.state.blend_set('ALPHA')
		gpu.state.line_width_set(1.5)
		shader.bind()
		shader.uniform_float('color', (0.35, 0.75, 1.0, 0.95))
		batch.draw(shader)
		gpu.state.line_width_set(1.0)
		gpu.state.blend_set('NONE')

	def _finish(self, context):
		context.space_data.shading.show_xray = self._previous_xray
		if self._draw_handle is not None:
			bpy.types.SpaceView3D.draw_handler_remove(self._draw_handle, 'WINDOW')
			self._draw_handle = None
		context.area.tag_redraw()

	def invoke(self, context, event):
		self._start = (event.mouse_region_x, event.mouse_region_y)
		self._current = self._start
		self._previous_xray = context.space_data.shading.show_xray
		context.space_data.shading.show_xray = True
		self._draw_handle = bpy.types.SpaceView3D.draw_handler_add(
			self._draw_box, (), 'WINDOW', 'POST_PIXEL'
		)
		context.window_manager.modal_handler_add(self)
		context.area.tag_redraw()
		return {'RUNNING_MODAL'}

	def modal(self, context, event):
		if event.type == 'MOUSEMOVE':
			self._current = (event.mouse_region_x, event.mouse_region_y)
			context.area.tag_redraw()
			return {'RUNNING_MODAL'}

		if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
			x1, y1 = self._start
			x2, y2 = self._current
			try:
				bpy.ops.view3d.select_box(
					'EXEC_DEFAULT',
					xmin=min(x1, x2),
					xmax=max(x1, x2),
					ymin=min(y1, y2),
					ymax=max(y1, y2),
					mode=self.selection_mode,
					wait_for_input=False,
				)
			finally:
				self._finish(context)
			return {'FINISHED'}

		if event.type in {'RIGHTMOUSE', 'ESC'}:
			self._finish(context)
			return {'CANCELLED'}

		return {'RUNNING_MODAL'}


class HP_OT_select_through_border(HP_SelectThroughMixin, bpy.types.Operator):
	bl_idname = "view3d.select_through_border"
	bl_label = "Select Through Border"
	selection_mode = 'SET'


class HP_OT_select_through_border_add(HP_SelectThroughMixin, bpy.types.Operator):
	bl_idname = "view3d.select_through_border_add"
	bl_label = "Add Select Through Border"
	selection_mode = 'ADD'


class HP_OT_select_through_border_sub(HP_SelectThroughMixin, bpy.types.Operator):
	bl_idname = "view3d.select_through_border_sub"
	bl_label = "Subtract Select Through Border"
	selection_mode = 'SUB'

classes = (
	HP_OT_select_through_border,
	HP_OT_select_through_border_add,
	HP_OT_select_through_border_sub,
)
register, unregister = bpy.utils.register_classes_factory(classes)

if __name__ == "__main__":
	register()
