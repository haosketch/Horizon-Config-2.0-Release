"""Horizon Config 2.0 portable startup marker for Blender 5.2."""

import bpy


VERSION = (2, 0, 6)
RELEASE = "Beta 1"


def register():
    print(
        "Horizon Config 2.0",
        ".".join(str(part) for part in VERSION),
        RELEASE,
        "loaded for Blender",
        bpy.app.version_string,
    )
    print("Based on and credited to HEAVYPOLY Config")


def unregister():
    pass


if __name__ == "__main__":
    register()
