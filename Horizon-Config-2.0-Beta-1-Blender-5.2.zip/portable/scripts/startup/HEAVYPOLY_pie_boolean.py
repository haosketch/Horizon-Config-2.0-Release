bl_info = {
    "name": "Horizon Config 2.0 Boolean Pie",
    "description": "Live boolean workflow with managed cutter collection",
    "author": "Vaughan Ling, Julien Gauthier",
    "version": (1, 2, 0),
    "blender": (5, 2, 0),
    "category": "Pie Menu",
}

import bpy
from bpy.types import Menu, Operator


CUTTER_COLLECTION = "Cutters"
CUTTER_FLAG = "hc_is_cutter"
CUTTER_COLOR = (0.8, 0.8, 0.8, 1.0)
CUTTER_RAY_VISIBILITY = (
    'visible_camera',
    'visible_diffuse',
    'visible_glossy',
    'visible_raycast',
    'visible_shadow',
    'visible_transmission',
    'visible_volume_scatter',
)


def _collection_in_tree(root, target):
    return root == target or any(
        _collection_in_tree(child, target) for child in root.children
    )


def _cutter_collection(context, create=True):
    collection = bpy.data.collections.get(CUTTER_COLLECTION)
    if collection is None and create:
        collection = bpy.data.collections.new(CUTTER_COLLECTION)
    if (
        collection is not None and
        create and
        not _collection_in_tree(context.scene.collection, collection)
    ):
        context.scene.collection.children.link(collection)
    return collection


def _is_cutter(obj):
    return bool(obj.get(CUTTER_FLAG, False) or "_Cutter" in obj.name)


def _cutters(context):
    collection = _cutter_collection(context, create=False)
    if collection is None:
        return []
    return [
        obj for obj in collection.all_objects
        if _is_cutter(obj) and obj.name in context.scene.objects
    ]


def _move_to_cutter_collection(context, obj):
    collection = _cutter_collection(context)
    if obj.name not in collection.objects:
        collection.objects.link(obj)
    for source in list(obj.users_collection):
        if source != collection:
            source.objects.unlink(obj)


def _next_cutter_name(base):
    stem = f"{base.name}_Cutter"
    index = 1
    name = f"{stem}_{index:02d}"
    while name in bpy.data.objects:
        index += 1
        name = f"{stem}_{index:02d}"
    return name


def _configure_cutter_display(cutter):
    """Keep the cutter as an overlay wire without a rendered surface."""
    cutter.display_type = 'WIRE'
    cutter.show_in_front = True
    cutter.show_wire = True
    cutter.show_all_edges = True
    cutter.hide_render = True
    cutter.color = CUTTER_COLOR
    for property_name in CUTTER_RAY_VISIBILITY:
        if hasattr(cutter, property_name):
            setattr(cutter, property_name, False)


def _mark_cutter(context, base, cutter):
    if not _is_cutter(cutter):
        cutter.name = _next_cutter_name(base)
    cutter[CUTTER_FLAG] = True
    cutter["hc_boolean_target"] = base.name
    _configure_cutter_display(cutter)
    _move_to_cutter_collection(context, cutter)


def _add_boolean(base, cutter, operation):
    modifier = base.modifiers.new(f"HC Boolean • {cutter.name}", 'BOOLEAN')
    modifier.operation = operation
    modifier.object = cutter
    if hasattr(modifier, "solver"):
        modifier.solver = 'EXACT'
    return modifier


def _apply_modifier(context, obj, modifier):
    with context.temp_override(
        object=obj,
        active_object=obj,
        selected_objects=[obj],
        selected_editable_objects=[obj],
    ):
        return bpy.ops.object.modifier_apply(modifier=modifier.name)


def _has_boolean_users(cutter):
    return any(
        modifier.type == 'BOOLEAN' and modifier.object == cutter
        for obj in bpy.data.objects
        for modifier in obj.modifiers
    )


def _configure_special_cutter(cutter, cutline, laser):
    if cutline == 'YES' and cutter.modifiers.get('HC Cutline') is None:
        modifier = cutter.modifiers.new('HC Cutline', 'SOLIDIFY')
        modifier.thickness = 0.02
    if laser == 'YES' and cutter.modifiers.get('HC Laser') is None:
        modifier = cutter.modifiers.new('HC Laser', 'SOLIDIFY')
        modifier.thickness = 100.0
        modifier.offset = 0.0


def _boolean_button(layout, text, operation, **options):
    operator = layout.operator(
        "view3d.hp_boolean_live",
        text=text,
        icon='MOD_BOOLEAN',
    )
    operator.bool_operation = operation
    operator.live = options.get("live", 'YES')
    operator.cutline = options.get("cutline", 'NO')
    operator.laser = options.get("laser", 'NO')
    operator.insetted = options.get("insetted", 'NO')
    return operator


class HP_MT_pie_boolean(Menu):
    bl_label = "HORIZON CONFIG 2.0 // BOOLEAN"

    def draw(self, context):
        pie = self.layout.menu_pie()

        create = pie.split().column(align=True)
        create.label(text="LIVE BOOLEAN")
        _boolean_button(create, "Subtract", 'DIFFERENCE')
        _boolean_button(create, "Union", 'UNION')
        _boolean_button(create, "Intersect", 'INTERSECT')

        cutters = pie.split().column(align=True)
        cutters.label(text="CUTTERS")
        show = cutters.row(align=True)
        show.operator("view3d.hp_boolean_set_cutters", text="Show", icon='HIDE_OFF').visible = True
        show.operator("view3d.hp_boolean_set_cutters", text="Hide", icon='HIDE_ON').visible = False
        cutters.operator("view3d.hp_boolean_select_cutters", text="Select All", icon='RESTRICT_SELECT_OFF')

        advanced = pie.split().column(align=True)
        advanced.label(text="ADVANCED")
        advanced.operator("view3d.hp_boolean_slice", text="Live Slice", icon='MOD_BOOLEAN')
        _boolean_button(advanced, "Wrap", 'WRAP')
        _boolean_button(advanced, "Inset Subtract", 'DIFFERENCE', insetted='YES')
        special = advanced.row(align=True)
        _boolean_button(special, "Cutline", 'DIFFERENCE', cutline='YES')
        _boolean_button(special, "Laser", 'DIFFERENCE', laser='YES')

        commit = pie.split().column(align=True)
        commit.label(text="COMMIT")
        commit.operator("view3d.hp_boolean_apply", text="Apply Booleans", icon='CHECKMARK').dup = 'NO'
        commit.operator("view3d.hp_boolean_apply", text="Apply to Copy", icon='DUPLICATE').dup = 'YES'
        all_modifiers = commit.operator(
            "view3d.hp_boolean_apply", text="Apply All Modifiers", icon='IMPORT'
        )
        all_modifiers.all = 'YES'

        evaluation = pie.split().column(align=True)
        evaluation.label(text="EVALUATION")
        enable = evaluation.row(align=True)
        enable.operator(
            "view3d.hp_boolean_set_modifiers", text="Enable", icon='CHECKBOX_HLT'
        ).enabled = True
        enable.operator(
            "view3d.hp_boolean_set_modifiers", text="Disable", icon='CHECKBOX_DEHLT'
        ).enabled = False

        destructive = pie.split().column(align=True)
        destructive.label(text="DESTRUCTIVE")
        _boolean_button(destructive, "Subtract + Apply", 'DIFFERENCE', live='NO')
        _boolean_button(destructive, "Union + Apply", 'UNION', live='NO')
        _boolean_button(destructive, "Intersect + Apply", 'INTERSECT', live='NO')

        pie.separator()
        pie.separator()


class HP_OT_boolean_live(Operator):
    bl_idname = "view3d.hp_boolean_live"
    bl_label = "Horizon Config 2.0 Boolean"
    bl_options = {'REGISTER', 'UNDO'}

    cutline: bpy.props.StringProperty(default='NO')
    laser: bpy.props.StringProperty(default='NO')
    live: bpy.props.StringProperty(default='YES')
    insetted: bpy.props.StringProperty(default='NO')
    displaytype: bpy.props.StringProperty(default='WIRE')
    showbounds: bpy.props.BoolProperty(default=False)
    bool_operation: bpy.props.StringProperty(default='DIFFERENCE')
    bool_solver: bpy.props.StringProperty(default='EXACT')

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            return False
        if obj.mode == 'EDIT':
            return True
        return len([item for item in context.selected_objects if item.type == 'MESH']) >= 2

    def execute(self, context):
        base = context.active_object

        if base.mode == 'EDIT':
            if self.live == 'YES':
                self.report({'INFO'}, "Live booleans need two objects in Object mode")
                return {'CANCELLED'}
            if self.bool_operation == 'WRAP':
                return {'CANCELLED'}
            return bpy.ops.mesh.intersect_boolean(operation=self.bool_operation)

        cutters = [
            obj for obj in context.selected_objects
            if obj != base and obj.type == 'MESH'
        ]
        if not cutters:
            self.report({'WARNING'}, "Select cutter object(s), then select the target last")
            return {'CANCELLED'}

        if self.bool_operation == 'WRAP':
            for wrapper in cutters:
                modifier = wrapper.modifiers.new(f"HC Wrap • {base.name}", 'BOOLEAN')
                modifier.operation = 'INTERSECT'
                modifier.object = base
                if hasattr(modifier, "solver"):
                    modifier.solver = 'EXACT'
                if wrapper.modifiers.get('HC Wrap Offset') is None:
                    displace = wrapper.modifiers.new('HC Wrap Offset', 'DISPLACE')
                    displace.strength = 0.02
                if self.live == 'NO':
                    _apply_modifier(context, wrapper, modifier)
            return {'FINISHED'}

        created = 0
        for cutter in cutters:
            _mark_cutter(context, base, cutter)
            _configure_special_cutter(cutter, self.cutline, self.laser)
            if self.insetted == 'YES' and cutter.modifiers.get('HC Inset') is None:
                inset = cutter.modifiers.new('HC Inset', 'SOLIDIFY')
                inset.thickness = -0.02
            modifier = _add_boolean(base, cutter, self.bool_operation)
            created += 1
            if self.live == 'NO':
                _apply_modifier(context, base, modifier)
                bpy.data.objects.remove(cutter, do_unlink=True)

        for obj in context.selected_objects:
            obj.select_set(False)
        base.select_set(True)
        context.view_layer.objects.active = base
        self.report({'INFO'}, f"Created {created} {self.bool_operation.title()} boolean(s)")
        return {'FINISHED'}


class HP_OT_boolean_set_cutters(Operator):
    bl_idname = "view3d.hp_boolean_set_cutters"
    bl_label = "Show or Hide All Cutters"
    bl_options = {'REGISTER', 'UNDO'}

    visible: bpy.props.BoolProperty(default=True)

    def execute(self, context):
        cutters = _cutters(context)
        for cutter in cutters:
            _configure_cutter_display(cutter)
            cutter.hide_set(not self.visible)
        self.report({'INFO'}, f"{'Shown' if self.visible else 'Hidden'} {len(cutters)} cutter(s)")
        return {'FINISHED'}


class HP_OT_boolean_toggle_cutters(Operator):
    bl_idname = "view3d.hp_boolean_toggle_cutters"
    bl_label = "Toggle All Cutters"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        cutters = _cutters(context)
        show = not any(not cutter.hide_get() for cutter in cutters)
        for cutter in cutters:
            _configure_cutter_display(cutter)
            cutter.hide_set(not show)
        return {'FINISHED'}


class HP_OT_boolean_set_modifiers(Operator):
    bl_idname = "view3d.hp_boolean_set_modifiers"
    bl_label = "Enable or Disable All Boolean Modifiers"
    bl_options = {'REGISTER', 'UNDO'}

    enabled: bpy.props.BoolProperty(default=True)

    def execute(self, context):
        changed = 0
        for obj in context.scene.objects:
            for modifier in obj.modifiers:
                if modifier.type == 'BOOLEAN' and modifier.object and _is_cutter(modifier.object):
                    modifier.show_viewport = self.enabled
                    modifier.show_render = self.enabled
                    changed += 1
        self.report({'INFO'}, f"{'Enabled' if self.enabled else 'Disabled'} {changed} boolean(s)")
        return {'FINISHED'}


class HP_OT_boolean_select_cutters(Operator):
    bl_idname = "view3d.hp_boolean_select_cutters"
    bl_label = "Select All Cutters"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        cutters = _cutters(context)
        for cutter in cutters:
            _configure_cutter_display(cutter)
            cutter.hide_set(False)
            cutter.select_set(True)
        if cutters:
            context.view_layer.objects.active = cutters[0]
        return {'FINISHED'}


class HP_OT_boolean_slice(Operator):
    bl_idname = "view3d.hp_boolean_slice"
    bl_label = "Live Boolean Slice"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (
            context.mode == 'OBJECT' and
            context.active_object is not None and
            context.active_object.type == 'MESH' and
            len([item for item in context.selected_objects if item.type == 'MESH']) == 2
        )

    def execute(self, context):
        base = context.active_object
        cutter = next(obj for obj in context.selected_objects if obj != base and obj.type == 'MESH')
        result = base.copy()
        result.data = base.data.copy()
        result.name = f"{base.name}_Slice"
        target_collection = base.users_collection[0] if base.users_collection else context.collection
        target_collection.objects.link(result)
        _mark_cutter(context, base, cutter)
        _add_boolean(base, cutter, 'DIFFERENCE')
        _add_boolean(result, cutter, 'INTERSECT')
        bpy.ops.object.select_all(action='DESELECT')
        base.select_set(True)
        result.select_set(True)
        context.view_layer.objects.active = result
        return {'FINISHED'}


class HP_OT_boolean_apply(Operator):
    bl_idname = "view3d.hp_boolean_apply"
    bl_label = "Apply Boolean Modifiers"
    bl_options = {'REGISTER', 'UNDO'}

    dup: bpy.props.StringProperty(default='NO')
    all: bpy.props.StringProperty(default='NO')

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and bool(context.selected_objects)

    def execute(self, context):
        sources = [obj for obj in context.selected_objects if not _is_cutter(obj)]
        cutters = set()
        applied = 0

        for source in sources:
            obj = source
            if self.dup == 'YES':
                obj = source.copy()
                obj.data = source.data.copy() if source.data else None
                obj.name = f"{source.name}_Applied"
                target_collection = source.users_collection[0] if source.users_collection else context.collection
                target_collection.objects.link(obj)

            modifiers = list(obj.modifiers) if self.all == 'YES' else [
                modifier for modifier in obj.modifiers if modifier.type == 'BOOLEAN'
            ]
            for modifier in modifiers:
                if modifier.type == 'BOOLEAN' and modifier.object:
                    cutters.add(modifier.object)
                if _apply_modifier(context, obj, modifier) == {'FINISHED'}:
                    applied += 1

        for cutter in cutters:
            if cutter.name in bpy.data.objects and not _has_boolean_users(cutter):
                bpy.data.objects.remove(cutter, do_unlink=True)

        self.report({'INFO'}, f"Applied {applied} modifier(s)")
        return {'FINISHED'}


classes = (
    HP_MT_pie_boolean,
    HP_OT_boolean_live,
    HP_OT_boolean_set_cutters,
    HP_OT_boolean_toggle_cutters,
    HP_OT_boolean_set_modifiers,
    HP_OT_boolean_select_cutters,
    HP_OT_boolean_slice,
    HP_OT_boolean_apply,
)

_register_classes, _unregister_classes = bpy.utils.register_classes_factory(classes)


def register():
    _register_classes()
    context = bpy.context
    if context.scene is None:
        return
    # Repair cutters created by Alpha 3/early Alpha 4 as soon as their file is
    # opened, so users do not have to recreate existing Boolean stacks.
    for cutter in list(context.scene.objects):
        if not _is_cutter(cutter):
            continue
        cutter[CUTTER_FLAG] = True
        _configure_cutter_display(cutter)
        _move_to_cutter_collection(context, cutter)


def unregister():
    _unregister_classes()


if __name__ == "__main__":
    register()
