bl_info = {
    "name": "Horizon Config 2.0 Operators",
    "description": "Operators that make for smooth blending",
    "author": "Vaughan Ling",
    "version": (1, 1, 0),
    "blender": (5, 2, 0),
    "location": "",
    "warning": "",
    "wiki_url": "",
    "category": "Operators"
    }

import bpy
import bmesh
from bpy.types import Menu
from bpy.types import Operator
from bpy.props import BoolProperty
from mathutils import Color

class HP_OT_unhide(bpy.types.Operator):
    bl_idname = "mesh.hp_unhide"         # unique identifier for buttons and menu items to reference.
    bl_label = "Unhide and keep selection"       # display name in the interface.
    bl_options = {'REGISTER', 'UNDO'}  # enable undo for the operator.

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH' and obj.mode == 'EDIT'

    def execute(self, context):
        # Blender now supports revealing without selecting the revealed
        # elements, so no temporary vertex group is needed.
        return bpy.ops.mesh.reveal(select=False)

class HP_OT_loopcut(bpy.types.Operator):
    bl_idname = "mesh.hp_loopcut"         # unique identifier for buttons and menu items to reference.
    bl_label = "Loopcut with tablet modals"       # display name in the interface.
    bl_options = {'REGISTER', 'UNDO'}  # enable undo for the operator.


    def modal(self, context, event):
        if event.type == 'MOUSEMOVE' and event.value == 'PRESS':
            print('Mousemove...')
            bpy.ops.mesh.loopcut_slide('INVOKE_DEFAULT')
            return {'RUNNING_MODAL'}
        if event.type in {'RIGHTMOUSE', 'ESC'}:  # Cancel
            return {'CANCELLED'}
        elif event.type == 'MOUSEMOVE' and event.value == 'RELEASE':
            bpy.context.scene.tool_settings.mesh_select_mode = (False, True, False)
            print('Release...')
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}
    def invoke(self, context, event):

        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

class HP_OT_smart_snap_cursor(bpy.types.Operator):
    bl_idname = "view3d.smart_snap_cursor"        # unique identifier for buttons and menu items to reference.
    bl_label = ""         # display name in the interface.
    bl_options = {'REGISTER', 'UNDO'}  # enable undo for the operator.
    def invoke(self, context, event):
        try:
            if context.active_object.mode == 'EDIT':
                if context.active_object.type == 'MESH':
                    if  context.object.data.total_vert_sel == 0:
                        bpy.ops.view3d.snap_cursor_to_center()
                    else:
                        bpy.ops.view3d.snap_cursor_to_selected()
                else:
                    bpy.ops.view3d.snap_cursor_to_selected()
            elif len(bpy.context.selected_objects) > 0:
                bpy.ops.view3d.snap_cursor_to_selected()
            else:
                bpy.ops.view3d.snap_cursor_to_center()
        except:
            bpy.ops.view3d.snap_cursor_to_center()
            #bpy.context.scene.tool_settings.transform_pivot_point = 'CURSOR'
        return {'FINISHED'}

class HP_OT_smart_snap_origin_collection(bpy.types.Operator):
    bl_idname = "view3d.smart_snap_origin_collection"        # unique identifier for buttons and menu items to reference.
    bl_label = "Smart Snap Origin Collection"         # display name in the interface.
    bl_options = {'REGISTER', 'UNDO'}  # enable undo for the operator.
    def invoke(self, context, event):
        print('smartsnaporigincollection')
        try:
            if context.active_object.mode == 'EDIT':
                if context.active_object.type == 'MESH':
                    if  context.object.data.total_vert_sel == 0:
                        bpy.ops.view3d.snap_cursor_to_center()
                        bpy.ops.object.mode_set(mode='OBJECT')
                        bpy.ops.object.origin_set(type = 'ORIGIN_CURSOR')
                        bpy.ops.object.mode_set(mode='EDIT')
                    else:
                        bpy.ops.view3d.snap_cursor_to_selected()
                        bpy.ops.object.mode_set(mode='OBJECT')
                        bpy.ops.object.instance_offset_from_cursor()
                        bpy.ops.object.mode_set(mode='EDIT')
                else:
                    bpy.ops.view3d.snap_cursor_to_selected()
                    bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
                    bpy.ops.object.origin_set(type = 'ORIGIN_CURSOR')
                    #bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
                    bpy.ops.object.mode_set(mode='EDIT', toggle=False)
            elif len(bpy.context.selected_objects) > 0:
                bpy.ops.view3d.snap_cursor_to_selected()
                bpy.ops.object.instance_offset_from_cursor()
            else:
                #bpy.ops.view3d.snap_cursor_to_center()
                #bpy.ops.object.origin_set(type = 'ORIGIN_CURSOR')
                bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
            #bpy.context.scene.tool_settings.transform_pivot_point = 'MEDIAN_POINT'
        except:
            return {'FINISHED'}
        return {'FINISHED'}
class HP_OT_smart_snap_origin(bpy.types.Operator):
    bl_idname = "view3d.smart_snap_origin"        # unique identifier for buttons and menu items to reference.
    bl_label = ""         # display name in the interface.
    bl_options = {'REGISTER', 'UNDO'}  # enable undo for the operator.
    def invoke(self, context, event):
        print('smartsnaporigin')
        cursor_start_location = bpy.context.scene.cursor.location * 1
        # print(cursor_start_location)
        try:
            if context.active_object.mode == 'EDIT':
                if context.active_object.type == 'MESH':
                    if  context.object.data.total_vert_sel == 0:
                        bpy.ops.view3d.snap_cursor_to_center()
                        bpy.ops.object.mode_set(mode='OBJECT')
                        bpy.ops.object.origin_set(type = 'ORIGIN_CURSOR')
                        bpy.ops.object.mode_set(mode='EDIT')
                    else:
                        bpy.ops.view3d.snap_cursor_to_selected()
                        bpy.ops.object.mode_set(mode='OBJECT')
                        bpy.ops.object.origin_set(type = 'ORIGIN_CURSOR')
                        bpy.ops.object.mode_set(mode='EDIT')
                else:
                    bpy.ops.view3d.snap_cursor_to_selected()
                    bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
                    bpy.ops.object.origin_set(type = 'ORIGIN_CURSOR')
                    #bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
                    bpy.ops.object.mode_set(mode='EDIT', toggle=False)
            elif len(bpy.context.selected_objects) > 0:
                bpy.ops.object.origin_set(type = 'ORIGIN_GEOMETRY')
            else:
                #bpy.ops.view3d.snap_cursor_to_center()
                #bpy.ops.object.origin_set(type = 'ORIGIN_CURSOR')
                bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
            #bpy.context.scene.tool_settings.transform_pivot_point = 'MEDIAN_POINT'
            print(cursor_start_location)
            bpy.context.scene.cursor.location = (cursor_start_location[0],cursor_start_location[1],cursor_start_location[2])
        except:
            return {'FINISHED'}
        return {'FINISHED'}

class HP_OT_duplicate_move(bpy.types.Operator):
    bl_idname = "view3d.hp_duplicate_move"
    bl_label = ""
    bl_options = {'REGISTER'}
    def invoke(self, context, event):
        if context.active_object is None:
            return {'CANCELLED'}
        if context.active_object.mode == 'OBJECT':
            return bpy.ops.object.duplicate_move('INVOKE_DEFAULT')
        if context.active_object.mode == 'EDIT':
            object_type = context.active_object.type
            if object_type == 'MESH':
                return bpy.ops.mesh.duplicate_move('INVOKE_DEFAULT')
            if object_type == 'CURVE':
                return bpy.ops.curve.duplicate_move('INVOKE_DEFAULT')
            if object_type == 'ARMATURE':
                return bpy.ops.armature.duplicate_move('INVOKE_DEFAULT')
            if object_type == 'GREASEPENCIL':
                return bpy.ops.grease_pencil.duplicate_move('INVOKE_DEFAULT')
        return {'CANCELLED'}



class HP_OT_PushAndSlide(bpy.types.Operator):
    bl_idname = "mesh.push_and_slide"        # unique identifier for buttons and menu items to reference.
    bl_label = "Push And Slide"         # display name in the interface.
    bl_options = {'REGISTER', 'UNDO'}  # enable undo for the operator.

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH' and obj.mode == 'EDIT'

    def invoke(self, context, event):
        if tuple(bpy.context.scene.tool_settings.mesh_select_mode) == (True, False, False):
            return bpy.ops.transform.vert_slide('INVOKE_DEFAULT', mirror=False, correct_uv=True)
        if tuple(bpy.context.scene.tool_settings.mesh_select_mode) == (False, False, True):
            return bpy.ops.transform.shrink_fatten('INVOKE_DEFAULT', use_even_offset=True, mirror=False)
        return bpy.ops.transform.edge_slide('INVOKE_DEFAULT', mirror=False, correct_uv=True)


class HP_OT_extrude(Operator):
    bl_label = "Context Sensitive Extrude"
    bl_idname = "mesh.hp_extrude"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type in {'MESH', 'CURVE'} and obj.mode == 'EDIT'

    def invoke(self, context, event):
        if bpy.context.object.type == 'CURVE':
            return bpy.ops.curve.extrude_move('INVOKE_DEFAULT')

        mesh = context.object.data
        selface = mesh.total_face_sel
        seledge = mesh.total_edge_sel
        selvert = mesh.total_vert_sel

        if selvert == 0:
            bpy.ops.mesh.select_mode(type='VERT')
            return bpy.ops.mesh.dupli_extrude_cursor('INVOKE_DEFAULT')
        if selface > 0:
            return bpy.ops.mesh.extrude_region_shrink_fatten('INVOKE_DEFAULT')
        return bpy.ops.mesh.extrude_context_move('INVOKE_DEFAULT')

    

class HP_OT_SmartScale(Operator):
    bl_idname = "view3d.smart_scale"        # unique identifier for buttons and menu items to reference.
    bl_label = "Context Sensitive Scale"         # display name in the interface.
    bl_options = {'REGISTER', 'UNDO'}  # enable undo for the operator.

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == 'VIEW_3D'

    def invoke(self, context, event):
        # Let Blender own the transform modal lifecycle. The previous wrapper
        # applied object scale on the first mouse move, even when the user later
        # cancelled the transform.
        return bpy.ops.transform.resize('INVOKE_DEFAULT', mirror=True)
class HP_OT_SmartBevel(bpy.types.Operator):
    bl_idname = "view3d.smart_bevel"        # unique identifier for buttons and menu items to reference.
    bl_label = "Smart Bevel"         # display name in the interface.
    bl_options = {'REGISTER', 'UNDO'}  # enable undo for the operator.

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH' and obj.mode == 'EDIT'

    def invoke(self, context, event):
        mesh = context.object.data
        bm = bmesh.from_edit_mesh(mesh)
        if not any(vertex.select for vertex in bm.verts):
            self.report({'INFO'}, "Nothing selected")
            return {'CANCELLED'}

        select_mode = tuple(context.scene.tool_settings.mesh_select_mode)
        if select_mode == (True, False, False):
            return bpy.ops.mesh.bevel(
                'INVOKE_DEFAULT', clamp_overlap=True, affect='VERTICES'
            )
        if select_mode == (False, False, True):
            bpy.ops.mesh.select_mode(type='EDGE')
            bpy.ops.mesh.region_to_loop()
            bm = bmesh.from_edit_mesh(mesh)
            if not any(vertex.select for vertex in bm.verts):
                bpy.ops.mesh.select_all(action='SELECT')
        return bpy.ops.mesh.bevel(
            'INVOKE_DEFAULT', clamp_overlap=True, miter_outer='ARC'
        )




class HP_OT_SeparateAndSelect(bpy.types.Operator):
    bl_idname = "object.separate_and_select"        # unique identifier for buttons and menu items to reference.
    bl_label = "Separate and Select"         # display name in the interface.
    bl_options = {'REGISTER', 'UNDO'}  # enable undo for the operator.
    def execute(self, context):

        bases = bpy.context.selected_objects
        if bpy.context.object.type == 'MESH':
            bpy.ops.mesh.separate(type='SELECTED')
        elif bpy.context.object.type == 'GPENCIL':
            bpy.ops.gpencil.stroke_separate(mode='POINT')
        elif bpy.context.object.type == 'GREASEPENCIL':
            bpy.ops.grease_pencil.stroke_separate(mode='POINT')

            # bpy.ops.gpencil.stroke_split()
        elif bpy.context.object.type == 'CURVE':
            bpy.ops.curve.separate()
        if bpy.context.object.type == 'GPENCIL':
            bpy.ops.gpencil.editmode_toggle()
        elif bpy.context.object.type == 'GREASEPENCIL':
            bpy.ops.object.mode_set('EDIT', toggle=True)
        else:
            bpy.ops.object.editmode_toggle()
            
        for b in bases:
            b.select_set(state=False)
        selected = bpy.context.selected_objects
        bpy.context.view_layer.objects.active = selected[-1]
        if bpy.context.object.type == 'GPENCIL':
            bpy.ops.gpencil.editmode_toggle()
        elif bpy.context.object.type == 'GREASEPENCIL':
            bpy.ops.grease_pencil.editmode_toggle()
        else:
            bpy.ops.object.editmode_toggle()
        if bpy.context.object.type == 'MESH':
            bpy.ops.mesh.select_all(action='SELECT')
        if bpy.context.object.type == 'CURVE':
            bpy.ops.curve.select_all(action='SELECT')
        return {'FINISHED'}

class HP_OT_SmartShadeSmooth(bpy.types.Operator):
    bl_idname = "view3d.smart_shade_smooth_toggle"        # unique identifier for buttons and menu items to reference.
    bl_label = "Smart Shade Smooth"         # display name in the interface.
    bl_options = {'REGISTER', 'UNDO'}  # enable undo for the operator.

    angle: bpy.props.FloatProperty(
        name="Angle",
        subtype='ANGLE',
        default=0.436332,
        min=0.0,
        max=3.141593,
    )

    @classmethod
    def poll(cls, context):
        return any(ob.type == 'MESH' for ob in context.selected_objects)

    def execute(self, context):
        original_active = context.view_layer.objects.active
        original_mode = original_active.mode if original_active else 'OBJECT'
        original_selection = list(context.selected_objects)

        if original_active and original_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        try:
            for obj in original_selection:
                if obj.type != 'MESH':
                    continue
                for selected in context.selected_objects:
                    selected.select_set(False)
                obj.select_set(True)
                context.view_layer.objects.active = obj
                has_visible_subdivision = any(
                    modifier.type == 'SUBSURF' and modifier.show_viewport
                    for modifier in obj.modifiers
                )
                if has_visible_subdivision:
                    bpy.ops.object.shade_smooth(keep_sharp_edges=False)
                else:
                    bpy.ops.object.shade_smooth_by_angle(
                        angle=self.angle,
                        keep_sharp_edges=True,
                    )
        finally:
            for selected in context.selected_objects:
                selected.select_set(False)
            for selected in original_selection:
                selected.select_set(True)
            if original_active:
                context.view_layer.objects.active = original_active
                if original_mode != 'OBJECT':
                    bpy.ops.object.mode_set(mode=original_mode)
        return {'FINISHED'}

    def invoke(self, context, event):
        return self.execute(context)

class HP_OT_toggle_render_material(bpy.types.Operator):
    bl_idname = "view3d.toggle_render_material"
    bl_label = "Toggle Material / Rendered"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == 'VIEW_3D'

    def execute(self, context):
        shading = context.space_data.shading
        shading.type = 'RENDERED' if shading.type == 'MATERIAL' else 'MATERIAL'
        return {'FINISHED'}



class HP_OT_Smart_Delete(bpy.types.Operator):
    bl_idname = "view3d.smart_delete"
    bl_label = "Smart Delete"
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        obj = context.object
        objType = getattr(obj, 'type', '')
        act = bpy.context.active_object

        try:
            if not act:
                for o in bpy.context.selected_objects:
                    bpy.context.view_layer.objects.active = o
                    act = bpy.context.active_object

            actname = act.name if act else ""

            # Object mode deletion logic
            if context.active_object.mode == 'OBJECT':
                if act.get('hc_is_cutter', False) or '_Cutter' in actname:
                    boolean_users = [
                        (owner, modifier.name)
                        for owner in context.scene.objects
                        for modifier in owner.modifiers
                        if modifier.type == 'BOOLEAN' and modifier.object == act
                    ]
                    bpy.ops.object.delete(use_global=False)
                    for owner, modifier_name in boolean_users:
                        modifier = owner.modifiers.get(modifier_name)
                        if modifier:
                            owner.modifiers.remove(modifier)
                else:
                    bpy.ops.object.delete(use_global=False)

            # Edit mode deletion for different object types
            elif objType == 'CURVE':
                if context.active_object.mode != 'OBJECT':
                    bpy.ops.curve.delete(type='VERT')

            # Grease Pencil handling (GPENCIL for 4.2, GREASEPENCIL for 4.3+)
            elif objType in {'GPENCIL', 'GREASEPENCIL'}:
                if context.active_object.mode != 'OBJECT':
                    if bpy.app.version < (4, 3, 0):
                        bpy.ops.gpencil.delete(type='POINTS')
                    else:
                        # Blender 4.3+ Grease Pencil API handling
                        bpy.ops.grease_pencil.delete()

            # Meta object handling
            elif objType == 'META':
                if context.active_object.mode != 'OBJECT':
                    bpy.ops.mball.delete_metaelems()

            # Mesh handling
            elif objType == 'MESH':
                if context.active_object.mode != 'OBJECT':
                    if tuple(bpy.context.scene.tool_settings.mesh_select_mode) == (False, False, True):
                        bpy.ops.mesh.delete(type='FACE')
                    else:
                        bpy.ops.mesh.delete(type='VERT')

        except Exception as e:
            print(f"Error in Smart Delete: {e}")
        
        return {'FINISHED'}







class HP_OT_Subdivision_Toggle(bpy.types.Operator):
    bl_idname = "view3d.subdivision_toggle"
    bl_label = ""
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return bool(context.selected_objects)

    def invoke(self, context, event):
        for obj in context.selected_objects:
            if not hasattr(obj, "modifiers"):
                continue
            modifier = next((m for m in obj.modifiers if m.type == 'SUBSURF'), None)
            if modifier is None:
                modifier = obj.modifiers.new("Subsurf_Base", "SUBSURF")
                modifier.render_levels = 3
                modifier.levels = 3
                modifier.show_in_editmode = True
                modifier.show_on_cage = False
                modifier.subdivision_type = 'CATMULL_CLARK'
            else:
                visible = not modifier.show_viewport
                modifier.show_viewport = visible
                modifier.show_render = visible

        return {'FINISHED'}

class HP_OT_SaveWithoutPrompt(bpy.types.Operator):
    bl_idname = "wm.save_without_prompt"
    bl_label = "Save without prompt"

    def execute(self, context):
        bpy.ops.wm.save_mainfile()
        return {'FINISHED'}
class HP_OT_RevertWithoutPrompt(bpy.types.Operator):
    bl_idname = "wm.revert_without_prompt"
    bl_label = "Revert without prompt"

    def execute(self, context):
        bpy.ops.wm.revert_mainfile()
        return {'FINISHED'}
class HP_OT_DeleteWithoutPrompt(bpy.types.Operator):
    bl_idname = "wm.delete_without_prompt"
    bl_label = "Delete without prompt"

    def execute(self, context):
        bpy.ops.object.delete()
        return {'FINISHED'}


class HP_OT_SetCollectionCenter(bpy.types.Operator):
    bl_idname = "view3d.hp_set_collection_center"         # unique identifier for buttons and menu items to reference.
    bl_label = "Set Collection Center"       # display name in the interface.
    bl_options = {'REGISTER', 'UNDO'}  # enable undo for the operator.

    def execute(self, context):
        ## 1 Save selection
        bpy.ops.view3d.snap_cursor_to_selected()
        #bpy.ops.view3d.snap_cursor_to_selected()
       # bpy.ops.object.instance_offset_from_cursor()
        return {'FINISHED'}

#### MOVE SPACE Y AXIS #####


class HP_TranslateModalOperator(bpy.types.Operator):
    """Toggle Move Mode and Y Constraint"""
    bl_idname = "object.modal_translate"
    bl_label = "Modal Translate"
    bl_options = {'REGISTER', 'UNDO'}

    is_moving: bpy.props.BoolProperty(default=False)
    constrain_y: bpy.props.BoolProperty(default=False)

    def modal(self, context, event):
        # Listen for keypresses
        if event.type == 'SPACE' and event.value == 'PRESS':
            # Toggle Y-axis constraint
            self.constrain_y = not self.constrain_y
            self.report({'INFO'}, f"Y-axis constraint {'enabled' if self.constrain_y else 'disabled'}")
            
            # Restart the transform operator with updated constraints
            bpy.ops.transform.translate(
                'INVOKE_DEFAULT',
                constraint_axis=(False, self.constrain_y, False)  # X, Y, Z constraints
            )
            return {'RUNNING_MODAL'}

        if event.type in {'LEFTMOUSE', 'RET'}:  # Confirm operation
            self.report({'INFO'}, "Transform Confirmed")
            self.is_moving = False
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:  # Cancel operation
            self.report({'INFO'}, "Transform Canceled")
            self.is_moving = False
            bpy.ops.ed.undo()  # Undo the transform
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        # Start the transform operator
        self.is_moving = True
        self.constrain_y = False  # Default: no constraint
        bpy.ops.transform.translate('INVOKE_DEFAULT')

        # Add a modal handler for post-transform actions
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

class OBJECT_OT_set_camera_off_wire(bpy.types.Operator):
    """Turn OFF Camera Visibility, Display as WIRE, Shadow ON"""
    bl_idname = "object.set_camera_off_wire"
    bl_label = "Hide From Camera (Wire Display)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.selected_objects

    def execute(self, context):
        is_cycles = context.scene.render.engine == 'CYCLES'
        for obj in context.selected_objects:
            if hasattr(obj, "visible_camera"):
                obj.visible_camera = False
            if is_cycles and hasattr(obj, "visible_shadow"):
                obj.visible_shadow = True
            obj.display_type = 'WIRE'
        self.report({'INFO'}, "Camera visibility OFF, Display as WIRE.")
        return {'FINISHED'}

class OBJECT_OT_set_camera_on_textured(bpy.types.Operator):
    """Turn ON Camera Visibility, Display as TEXTURED"""
    bl_idname = "object.set_camera_on_textured"
    bl_label = "Show in Camera (Textured Display)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.selected_objects

    def execute(self, context):
        for obj in context.selected_objects:
            if hasattr(obj, "visible_camera"):
                obj.visible_camera = True
            obj.display_type = 'TEXTURED'
        self.report({'INFO'}, "Camera visibility ON, Display as TEXTURED.")
        return {'FINISHED'}

class OBJECT_OT_select_camera_hidden(bpy.types.Operator):
    """Select all geometry objects with Camera Visibility OFF"""
    bl_idname = "object.select_camera_hidden"
    bl_label = "Select Hidden From Camera"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bpy.ops.object.select_all(action='DESELECT')
        count = 0
        geometry_types = {'MESH', 'CURVE', 'SURFACE', 'META', 'FONT'}

        for obj in context.scene.objects:
            if (
                obj.type in geometry_types
                and hasattr(obj, "visible_camera")
                and not obj.visible_camera
            ):
                obj.select_set(True)
                count += 1

        self.report({'INFO'}, f"Selected {count} camera-hidden geometry objects.")
        return {'FINISHED'}




def draw_func(self, context):
    layout = self.layout
    layout.separator()
    layout.operator("object.set_camera_off_wire", icon='HIDE_ON')
    layout.operator("object.set_camera_on_textured", icon='HIDE_OFF')
    layout.operator("object.select_camera_hidden", icon='RESTRICT_VIEW_ON')


classes = (
    HP_OT_SaveWithoutPrompt,
    HP_OT_RevertWithoutPrompt,
    HP_OT_DeleteWithoutPrompt,
    HP_OT_duplicate_move,
    HP_OT_Subdivision_Toggle,
    HP_OT_toggle_render_material,
    HP_OT_Smart_Delete,
    HP_OT_SmartShadeSmooth,
    HP_OT_SeparateAndSelect,
    HP_OT_PushAndSlide,
    HP_OT_SmartBevel,
    HP_OT_smart_snap_cursor,
    HP_OT_smart_snap_origin,
    HP_OT_smart_snap_origin_collection,
    HP_OT_extrude,
    HP_OT_loopcut,
    HP_OT_SmartScale,
    HP_OT_unhide,
    HP_OT_SetCollectionCenter,
    HP_TranslateModalOperator,
    OBJECT_OT_set_camera_off_wire,
    OBJECT_OT_set_camera_on_textured,
    OBJECT_OT_select_camera_hidden,

)
#register, unregister = bpy.utils.register_classes_factory(classes)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.VIEW3D_MT_object_context_menu.append(draw_func)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    bpy.types.VIEW3D_MT_object_context_menu.remove(draw_func)

if __name__ == "__main__":
    register()
