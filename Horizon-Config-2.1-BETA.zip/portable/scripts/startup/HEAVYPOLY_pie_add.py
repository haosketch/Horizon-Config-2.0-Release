bl_info = {
    "name": "Pie Add",
    "description": "",
    "author": "Vaughan Ling",
    "version": (0, 1, 0),
    "blender": (2, 80, 0),
    "location": "",
    "warning": "",
    "wiki_url": "",
    "category": "Pie Menu"
    }

import bpy
import bmesh
from bpy.types import Menu
from bpy.types import Operator
from bpy.props import BoolProperty
from mathutils import Matrix, Vector


# Keep the original pie's sizes and tessellation.  Edit Mode geometry is built in
# an orthonormal world frame, then mapped through the host's full inverse transform.
MESH_PRIMITIVES = {
    'Cube': ('primitive_cube_add', {'size': 1.0}),
    'Cube_Small': ('primitive_cube_add', {'size': 0.1}),
    'Plane': ('primitive_plane_add', {'size': 2.0}),
    'Plane_Small': ('primitive_plane_add', {'size': 0.1}),
    'Circle_6': ('primitive_circle_add', {'vertices': 6, 'radius': 0.08, 'fill_type': 'NGON'}),
    'Circle_8': ('primitive_circle_add', {'vertices': 8, 'radius': 0.25, 'fill_type': 'NGON'}),
    'Circle_12': ('primitive_circle_add', {'vertices': 12, 'radius': 0.25, 'fill_type': 'NGON'}),
    'Circle_24': ('primitive_circle_add', {'vertices': 24, 'radius': 0.25, 'fill_type': 'NGON'}),
    'Circle_32': ('primitive_circle_add', {'vertices': 32, 'radius': 1.0, 'fill_type': 'NGON'}),
    'Cylinder_6': ('primitive_cylinder_add', {'vertices': 6, 'radius': 0.08, 'depth': 0.1}),
    'Cylinder_8': ('primitive_cylinder_add', {'vertices': 8, 'radius': 0.25, 'depth': 0.5}),
    'Cylinder_12': ('primitive_cylinder_add', {'vertices': 12, 'radius': 0.25, 'depth': 0.5}),
    'Cylinder_24': ('primitive_cylinder_add', {'vertices': 24, 'radius': 0.25, 'depth': 0.5}),
    'Cylinder_32': ('primitive_cylinder_add', {'vertices': 32, 'radius': 1.0, 'depth': 2.0}),
    'Cylinder_64': ('primitive_cylinder_add', {'vertices': 64, 'radius': 1.0, 'depth': 2.0}),
    'Cylinder_128': ('primitive_cylinder_add', {'vertices': 128, 'radius': 1.0, 'depth': 2.0}),
    'Sphere_12': ('primitive_uv_sphere_add', {'segments': 12, 'ring_count': 6, 'radius': 0.1}),
    'Sphere_24': ('primitive_uv_sphere_add', {'segments': 24, 'ring_count': 12, 'radius': 1.0}),
    'Sphere_32': ('primitive_uv_sphere_add', {'segments': 32, 'ring_count': 16, 'radius': 1.0}),
}


def _selected_face_placement(mesh, world, world_inverse):
    """Return a source-face anchor and a stable, right-handed world frame."""
    selected = [face for face in mesh.faces if face.select and not face.hide]
    if not selected:
        return None
    normal_matrix = world_inverse.to_3x3().transposed()
    determinant = abs(world.to_3x3().determinant())
    candidates = []
    for index, face in enumerate(selected):
        face.normal_update()
        normal = normal_matrix @ face.normal
        if normal.length_squared < 1e-24:
            continue
        # The inverse transpose follows the face's outward normal, including
        # mirrored hosts; multiplying by determinant's sign would point inward.
        area = face.calc_area() * determinant * normal.length
        if area <= 0.0:
            continue
        candidates.append((face, world @ face.calc_center_median(), normal.normalized(), area, index))
    if not candidates:
        raise ValueError("Selected face has no usable surface normal")
    active = next((item for item in candidates if item[0] == mesh.faces.active), None)
    reference = active or max(candidates, key=lambda item: (item[3], -item[4]))
    face, anchor, normal, _area, _index = reference
    if active is None and all(
        candidate[2].dot(normal) > 1.0 - 1e-6
        and abs((candidate[1] - anchor).dot(normal)) < 1e-5
        for candidate in candidates
    ):
        total_area = sum(item[3] for item in candidates)
        anchor = sum((item[1] * item[3] for item in candidates), Vector()) / total_area
        normal = sum((item[2] * item[3] for item in candidates), Vector()).normalized()

    # Longest face edge gives a reproducible in-plane direction without relying
    # on the viewport, cursor rotation or a temporary custom orientation.
    tangents = []
    for loop in face.loops:
        edge = world.to_3x3() @ (loop.link_loop_next.vert.co - loop.vert.co)
        tangents.append(edge - normal * edge.dot(normal))
    tangent = max(tangents, key=lambda item: item.length_squared)
    if tangent.length_squared < 1e-24:
        raise ValueError("Selected face has no usable edge direction")
    tangent.normalize()
    bitangent = normal.cross(tangent).normalized()
    frame = Matrix((tangent, bitangent, normal)).transposed().to_4x4()
    return anchor, frame


def _primitive_support_offset(operator_name, settings):
    if operator_name == 'primitive_cylinder_add':
        return settings['depth'] / 2.0
    if operator_name == 'primitive_cube_add':
        return settings['size'] / 2.0
    if operator_name == 'primitive_uv_sphere_add':
        return settings['radius']
    return 0.0

class HP_MT_pie_add(Menu):
    bl_label = "Add"
    def draw(self, context):
        layout = self.layout
        view = context.space_data
        obj = context.active_object
        pie = layout.menu_pie()
        # Left
        split = pie.split()
        col = split.column()
        col.scale_y=1.5
        col.scale_x=1.1
        col.operator("view3d.hp_add_primitive", icon='MESH_PLANE', text="Big").type = 'Plane'
        col.operator("view3d.hp_add_primitive", icon='MESH_PLANE', text="Small").type = 'Plane_Small'
        col.operator("view3d.hp_add_primitive", icon='MESH_CUBE', text="Big").type = 'Cube'
        col.operator("view3d.hp_add_primitive", icon='MESH_CUBE', text="Small").type = 'Cube_Small'
        col = split.column()
        col.scale_y=1.5
        col.scale_x=1
        col.operator("view3d.hp_add_primitive", icon='MESH_CIRCLE', text="6").type = 'Circle_6'
        col.operator("view3d.hp_add_primitive", icon='MESH_CIRCLE', text="8").type = 'Circle_8'
        col.operator("view3d.hp_add_primitive", icon='MESH_CIRCLE', text="12").type = 'Circle_12'
        col.operator("view3d.hp_add_primitive", icon='MESH_CIRCLE', text="24").type = 'Circle_24'
        col.operator("view3d.hp_add_primitive", icon='MESH_CIRCLE', text="32").type = 'Circle_32'
        # Right
        split = pie.split()
        col = split.column()
        col.scale_y=1.5
        col.scale_x=1
        col.operator("view3d.hp_add_primitive", icon='MESH_UVSPHERE', text="12").type = 'Sphere_12'
        col.operator("view3d.hp_add_primitive", icon='MESH_UVSPHERE', text="24").type = 'Sphere_24'
        col.operator("view3d.hp_add_primitive", icon='MESH_UVSPHERE', text="32").type = 'Sphere_32'
        # Top
        split = pie.split()
        col = split.column()
        col.scale_y=1.5
        col.scale_x=1
        col.operator("view3d.hp_add_primitive", icon='IPO_EASE_IN_OUT', text="Curve").type = 'Curve'
        col.operator("view3d.hp_add_primitive", icon='CURVE_NCIRCLE', text="Curve").type = 'Curve Circle'
        col = split.column()
        col.scale_y=1.5
        col.scale_x=1
        col.operator("view3d.hp_add_primitive", icon='LIGHT', text="Light").type = 'Point_Light'
        col.operator("view3d.hp_add_primitive", icon='LIGHT_AREA', text="Light").type = 'Area_Light'
        col.operator("view3d.hp_add_primitive", icon='GREASEPENCIL', text="GPencil").type = 'Grease_Pencil'
        # Bottom
        split = pie.split()
        col = split.column()
        col.scale_y=1.5
        col.scale_x=1
        col.operator("view3d.hp_add_primitive", icon='MESH_CYLINDER', text="6").type = 'Cylinder_6'
        col.operator("view3d.hp_add_primitive", icon='MESH_CYLINDER', text="8").type = 'Cylinder_8'
        col.operator("view3d.hp_add_primitive", icon='MESH_CYLINDER', text="12").type = 'Cylinder_12'
        col.operator("view3d.hp_add_primitive", icon='MESH_CYLINDER', text="24").type = 'Cylinder_24'
        col = split.column()
        col.scale_y=1.5
        col.scale_x=1
        col.operator("view3d.hp_add_primitive", icon='MESH_CYLINDER', text="32").type = 'Cylinder_32'
        col.operator("view3d.hp_add_primitive", icon='MESH_CYLINDER', text="64").type = 'Cylinder_64'
        col.operator("view3d.hp_add_primitive", icon='MESH_CYLINDER', text="128").type = 'Cylinder_128'

        
        # Top Left
            
        split = pie.split()

        
        # Top Right
        split = pie.split()
        
        # Bottom Left
            
        split = pie.split()
        col = split.column()
        col.scale_y=1.5
        col.scale_x=1

        # Bottom Right
            

        
class HP_OT_add_primitive(bpy.types.Operator):
    bl_idname = "view3d.hp_add_primitive"        # unique identifier for buttons and menu items to reference.
    bl_label = "HC Add Primitive"         # display name in the interface.
    bl_options = {'REGISTER', 'UNDO',}  # enable undo for the operator.
    type: bpy.props.StringProperty(name="Type")

    def execute(self, context):
        return self.invoke(context, None)

    def _add_edit_mesh_primitive(self, context):
        obj = context.edit_object
        # An inverse exists even for rotated, mirrored and non-uniformly scaled
        # hosts.  Zero scale has no world-to-local solution; do not alter it.
        if obj.matrix_world.to_3x3().determinant() == 0.0:
            self.report({'WARNING'}, "Cannot add a primitive to an object with zero scale")
            return {'CANCELLED'}
        mesh = bmesh.from_edit_mesh(obj.data)
        selected = [vertex for vertex in mesh.verts if vertex.select and not vertex.hide]
        location = context.scene.cursor.location.copy()
        if selected:
            center = sum((vertex.co for vertex in selected), Vector()) / len(selected)
            location = obj.matrix_world @ center
        operator_name, settings = MESH_PRIMITIVES[self.type]
        # Keep the whole inverse, including scale/shear, so the new primitive
        # retains its world dimensions even in a non-uniformly scaled host.
        try:
            world_inverse = obj.matrix_world.inverted()
        except ValueError:
            self.report({'WARNING'}, "Cannot add a primitive: object transform cannot be inverted")
            return {'CANCELLED'}
        frame = Matrix.Identity(4)
        if context.tool_settings.mesh_select_mode[2]:
            try:
                placement = _selected_face_placement(mesh, obj.matrix_world, world_inverse)
            except ValueError as error:
                self.report({'WARNING'}, str(error))
                return {'CANCELLED'}
            if placement is not None:
                anchor, frame = placement
                normal = frame.to_3x3() @ Vector((0.0, 0.0, 1.0))
                location = anchor + normal * _primitive_support_offset(operator_name, settings)
        to_local = world_inverse @ Matrix.Translation(location) @ frame
        # Native Add supplies UVs.  Reuse the active layer (or create the first)
        # and write only the new primitive's loops, leaving existing UVs intact.
        uv_layer = mesh.loops.layers.uv.verify()
        old_verts = set(mesh.verts)
        old_edges = set(mesh.edges)
        old_faces = set(mesh.faces)
        if operator_name == 'primitive_cube_add':
            bmesh.ops.create_cube(mesh, size=settings['size'], matrix=to_local, calc_uvs=True)
        elif operator_name == 'primitive_plane_add':
            half_size = settings['size'] / 2.0
            vertices = [
                mesh.verts.new(to_local @ Vector(point))
                for point in (
                    (-half_size, -half_size, 0.0),
                    (half_size, -half_size, 0.0),
                    (half_size, half_size, 0.0),
                    (-half_size, half_size, 0.0),
                )
            ]
            face = mesh.faces.new(vertices)
            for loop, uv in zip(face.loops, ((0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0))):
                loop[uv_layer].uv = uv
        elif operator_name == 'primitive_circle_add':
            bmesh.ops.create_circle(
                mesh, segments=settings['vertices'], radius=settings['radius'],
                cap_ends=True, cap_tris=False, matrix=to_local, calc_uvs=True,
            )
        elif operator_name == 'primitive_cylinder_add':
            bmesh.ops.create_cone(
                mesh, segments=settings['vertices'], radius1=settings['radius'],
                radius2=settings['radius'], depth=settings['depth'],
                cap_ends=True, cap_tris=False, matrix=to_local, calc_uvs=True,
            )
        elif operator_name == 'primitive_uv_sphere_add':
            bmesh.ops.create_uvsphere(
                mesh, u_segments=settings['segments'], v_segments=settings['ring_count'],
                radius=settings['radius'], matrix=to_local, calc_uvs=True,
            )

        # A reflected object matrix reverses local winding.  Reverse only new
        # faces so inverse-transpose shading normals still point outward.
        if obj.matrix_world.to_3x3().determinant() < 0.0:
            bmesh.ops.reverse_faces(mesh, faces=[face for face in mesh.faces if face not in old_faces])

        # Match native Add selection/material assignment while changing neither
        # old vertex coordinates nor the object's slots, transform or modifiers.
        for face in old_faces:
            face.select_set(False)
        for edge in old_edges:
            edge.select_set(False)
        for vertex in old_verts:
            vertex.select_set(False)
        mesh.select_history.clear()
        for vertex in mesh.verts:
            if vertex not in old_verts:
                vertex.select_set(True)
        for edge in mesh.edges:
            if edge not in old_edges:
                edge.select_set(True)
        material_index = min(obj.active_material_index, max(0, len(obj.material_slots) - 1))
        for face in mesh.faces:
            if face not in old_faces:
                face.material_index = material_index
                face.select_set(True)
                mesh.faces.active = face
        mesh.normal_update()
        mesh.select_flush_mode()
        bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=True)
        return {'FINISHED'}

    def invoke(self, context, event):
        if context.mode == 'EDIT_MESH' and self.type in MESH_PRIMITIVES:
            return self._add_edit_mesh_primitive(context)
        if self.type == 'Curve Circle':
            # A curve cannot be joined into an editable mesh.  This pie item was
            # previously an unhandled no-op, sometimes followed by object.join.
            if context.mode not in {'OBJECT', 'EDIT_CURVE'}:
                self.report({'INFO'}, "Add a curve circle in Object Mode or Curve Edit Mode")
                return {'CANCELLED'}
            return bpy.ops.curve.primitive_bezier_circle_add(align='WORLD')
        cur = bpy.context.scene.cursor.location
        cur = list(cur)
        addob = False
        align_mode = 'WORLD'
        space = context.space_data
        if space and space.type == 'VIEW_3D' and not space.region_3d.is_perspective:
            align_mode = 'VIEW'
        def prim(self, type):
            if self.type == 'Cube':
                bpy.ops.mesh.primitive_cube_add(size=1, align=align_mode)
            if self.type == 'Cube_Small':           
                bpy.ops.mesh.primitive_cube_add(size=.1, align=align_mode)
            if self.type == 'Plane':
                bpy.ops.mesh.primitive_plane_add(align=align_mode)
            if self.type == 'Plane_Small':
                bpy.ops.mesh.primitive_plane_add(size=.1, align=align_mode)
            if self.type == 'Circle_6':
                bpy.ops.mesh.primitive_circle_add(vertices=6, radius=0.08, fill_type='NGON', align=align_mode)
            if self.type == 'Circle_8':
                bpy.ops.mesh.primitive_circle_add(fill_type='NGON', radius=.25, vertices=8, align=align_mode)
            if self.type == 'Circle_12':
                bpy.ops.mesh.primitive_circle_add(fill_type='NGON', radius=.25, vertices=12, align=align_mode)
            if self.type == 'Circle_24':
                bpy.ops.mesh.primitive_circle_add(fill_type='NGON', radius=.25, vertices=24, align=align_mode)
            if self.type == 'Circle_32':
                bpy.ops.mesh.primitive_circle_add(fill_type='NGON', vertices=32, align=align_mode)


            if self.type == 'Cylinder_6':
                bpy.ops.mesh.primitive_cylinder_add(radius=.08,depth=.1, vertices=6, align=align_mode)
            if self.type == 'Cylinder_8':
                bpy.ops.mesh.primitive_cylinder_add(radius=.25,depth=.5, vertices=8, align=align_mode)
            if self.type == 'Cylinder_12':
                bpy.ops.mesh.primitive_cylinder_add(radius=.25,depth=.5, vertices=12, align=align_mode)
            if self.type == 'Cylinder_24':
                bpy.ops.mesh.primitive_cylinder_add(radius=.25,depth=.5, vertices=24, enter_editmode=False, align=align_mode)
            if self.type == 'Cylinder_32':
                bpy.ops.mesh.primitive_cylinder_add(vertices=32, align=align_mode)
            if self.type == 'Cylinder_64':
                bpy.ops.mesh.primitive_cylinder_add(vertices=64, align=align_mode)            
            if self.type == 'Cylinder_128':
                bpy.ops.mesh.primitive_cylinder_add(vertices=128, align=align_mode)
            if self.type == 'Sphere_12':           
                bpy.ops.mesh.primitive_uv_sphere_add(segments=12, ring_count=6, radius=0.1, align=align_mode)
            if self.type == 'Sphere_24':           
                bpy.ops.mesh.primitive_uv_sphere_add(segments=24, ring_count=12, align=align_mode)
            if self.type == 'Sphere_32':           
                bpy.ops.mesh.primitive_uv_sphere_add(align=align_mode)

            if self.type == 'Grease_Pencil':
                bpy.ops.object.grease_pencil_add()
                bpy.ops.object.mode_set(mode='PAINT_GREASE_PENCIL')
            if self.type == 'Curve':
                bpy.ops.curve.primitive_nurbs_path_add()
                bpy.ops.object.editmode_toggle()
            if self.type == 'Point_Light':
                bpy.ops.object.mode_set(mode='OBJECT')
                bpy.ops.object.light_add(type='POINT', radius=.05, align=align_mode)
                bpy.context.active_object.name = 'Light Point'
                bpy.context.object.data.energy = 200
                bpy.context.object.data.shadow_soft_size = 0.3
                bpy.context.object.data.shadow_buffer_clip_start = 0.1
                
            if self.type == 'Area_Light':
                bpy.ops.object.mode_set(mode='OBJECT')
                bpy.ops.object.light_add(type='AREA', radius=1, align=align_mode)
                bpy.context.active_object.name = 'Light Area'
                bpy.context.active_object.data.shape = 'RECTANGLE'
                bpy.context.active_object.data.size = 1
                bpy.context.active_object.data.size_y = 3
                bpy.context.active_object.data.energy = 200
                bpy.context.active_object.data.shadow_soft_size = 0.3
                bpy.context.active_object.data.shadow_buffer_clip_start = 0.1

        t_axis = bpy.context.scene.transform_orientation_slots[0].type
        def create_aligned_to_faces():
            print('Creating Aligned to Faces')
            o = bpy.context.view_layer.objects.active
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.transform.create_orientation(name="AddAxis", use=True, overwrite=True)
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT', toggle = False)
            prim(self, type)
            bpy.ops.transform.transform(mode='ALIGN', value=(0, 0, 0, 0))
            if addob == False:
                o.select_set(state=True)
                bpy.context.view_layer.objects.active = o
                bpy.ops.object.join()
                bpy.ops.object.mode_set(mode='EDIT')
                # bpy.ops.object.face_map_add()
                # bpy.ops.object.face_map_select()
                # bpy.ops.object.face_map_remove_from()
                # bpy.ops.object.face_map_remove()
        if self.type in {'Point_Light', 'Area_Light', 'Grease_Pencil'}:
            addob = True

        if bpy.context.object.data.total_vert_sel == 0:
            print('Creating at Origin')
            prim(self, type)
            
            

        elif tuple(bpy.context.scene.tool_settings.mesh_select_mode) == (False, False, True):
            create_aligned_to_faces()
        else:
            if bpy.context.area.spaces.active.region_3d.view_perspective == 'ORTHO':
                bpy.ops.view3d.snap_cursor_to_selected()
                prim(self, type)
            else:
                bpy.ops.view3d.snap_cursor_to_selected()
                prim(self, type)
        bpy.context.scene.cursor.location = cur
        bpy.data.scenes[0].transform_orientation_slots[0].type = t_axis
        return {'FINISHED'}

        
classes = (
    HP_MT_pie_add,
    HP_OT_add_primitive,
)
register, unregister = bpy.utils.register_classes_factory(classes)

if __name__ == "__main__":
    register()
