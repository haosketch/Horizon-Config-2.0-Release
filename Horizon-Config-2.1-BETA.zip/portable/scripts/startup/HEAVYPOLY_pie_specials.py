bl_info = {
    "name": "Pie Specials",
    "description": "Specials Modes",
    "author": "Vaughan Ling",
    "version": (1, 1, 0),
    "blender": (5, 2, 0),
    "location": "",
    "warning": "",
    "wiki_url": "",
    "category": "Pie Menu"
    }

import bpy
import os
import math
import mathutils
import numpy as np

from bpy.types import Menu
from bpy.types import Operator
from bpy.props import BoolProperty
from mathutils import Matrix
from bpy.props import StringProperty

# Path to the .blend file containing the node group
NODE_GROUP_FILE = os.path.join(os.path.dirname(__file__), "HP_Nodes.blend")
HC_OUTLINE_MATERIAL = "HC Outline"
HC_BASE_MATERIAL = "HC Base"
HC_OUTLINE_MODIFIER = "HC Outline"


def operator_exists(idname):
    try:
        category, name = idname.split('.', 1)
        getattr(getattr(bpy.ops, category), name).get_rna_type()
        return True
    except (AttributeError, KeyError):
        return False


def _ensure_principled_material(name, color, roughness=0.6):
    material = bpy.data.materials.get(name)
    if material is None:
        material = bpy.data.materials.new(name)
    material.diffuse_color = color
    material.use_nodes = True
    material.use_backface_culling = name == HC_OUTLINE_MATERIAL
    principled = material.node_tree.nodes.get('Principled BSDF')
    if principled:
        principled.inputs['Base Color'].default_value = color
        principled.inputs['Roughness'].default_value = roughness
    return material


def _ensure_outline_modifier(obj, thickness):
    if not obj.data.materials:
        obj.data.materials.append(
            _ensure_principled_material(
                HC_BASE_MATERIAL,
                (0.18, 0.18, 0.18, 1.0),
            )
        )

    outline_material = _ensure_principled_material(
        HC_OUTLINE_MATERIAL,
        (0.008, 0.008, 0.008, 1.0),
        roughness=0.72,
    )
    if outline_material.name not in {
        slot.material.name for slot in obj.material_slots if slot.material
    }:
        obj.data.materials.append(outline_material)
    outline_index = next(
        index
        for index, slot in enumerate(obj.material_slots)
        if slot.material == outline_material
    )

    modifier = obj.modifiers.get(HC_OUTLINE_MODIFIER)
    if modifier is None or modifier.type != 'SOLIDIFY':
        modifier = obj.modifiers.new(HC_OUTLINE_MODIFIER, 'SOLIDIFY')
    modifier.thickness = thickness
    modifier.offset = -1.0
    modifier.use_flip_normals = True
    modifier.use_rim = False
    modifier.use_even_offset = True
    modifier.solidify_mode = 'EXTRUDE'
    # A large positive offset clamps every generated shell face to the final
    # dark material slot, including objects with several source materials.
    modifier.material_offset = outline_index
    modifier.material_offset_rim = outline_index
    return modifier


class HC_OT_outline_toggle(bpy.types.Operator):
    bl_idname = "object.hc_outline_toggle"
    bl_label = "Horizon Outline"
    bl_description = "Create or toggle an inverted-hull outline on selected meshes"
    bl_options = {'REGISTER', 'UNDO'}

    thickness: bpy.props.FloatProperty(
        name="Outline Width",
        description="Negative Solidify thickness used for the outside shell",
        default=-0.015,
        min=-1.0,
        max=-0.0001,
        soft_min=-0.1,
        soft_max=-0.001,
        precision=4,
        subtype='DISTANCE',
    )

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and any(
            obj.type == 'MESH' for obj in context.selected_objects
        )

    def execute(self, context):
        objects = [obj for obj in context.selected_objects if obj.type == 'MESH']
        outlines = [obj.modifiers.get(HC_OUTLINE_MODIFIER) for obj in objects]
        turn_on = not all(
            modifier and modifier.type == 'SOLIDIFY' and modifier.show_viewport
            for modifier in outlines
        )

        for obj in objects:
            modifier = _ensure_outline_modifier(obj, self.thickness)
            modifier.show_viewport = turn_on
            modifier.show_render = turn_on

        self.report(
            {'INFO'},
            f"Horizon Outline {'enabled' if turn_on else 'disabled'} on "
            f"{len(objects)} object(s)",
        )
        return {'FINISHED'}


class HP_MT_pie_modifiers(Menu):
    """Restored modifier pie targeted by the historical 1 hotkey."""

    bl_label = "HORIZON CONFIG 2.1 BETA MODIFIERS"

    def draw(self, context):
        pie = self.layout.menu_pie()

        bevel = pie.operator('object.modifier_add', text='Bevel', icon='MOD_BEVEL')
        bevel.type = 'BEVEL'
        solidify = pie.operator(
            'object.modifier_add', text='Solidify', icon='MOD_SOLIDIFY'
        )
        solidify.type = 'SOLIDIFY'
        subdiv = pie.operator(
            'object.modifier_add', text='Subdivision', icon='MOD_SUBSURF'
        )
        subdiv.type = 'SUBSURF'
        pie.operator(
            'object.hc_outline_toggle', text='HC Outline', icon='SHADING_RENDERED'
        )
        mirror = pie.operator('object.modifier_add', text='Mirror', icon='MOD_MIRROR')
        mirror.type = 'MIRROR'
        array = pie.operator('object.modifier_add', text='Array', icon='MOD_ARRAY')
        array.type = 'ARRAY'
        weld = pie.operator('object.modifier_add', text='Weld', icon='AUTOMERGE_ON')
        weld.type = 'WELD'
        normals = pie.operator(
            'object.modifier_add', text='Weighted Normal', icon='MOD_NORMALEDIT'
        )
        normals.type = 'WEIGHTED_NORMAL'

# Specials Pie
class HP_MT_pie_specials(Menu):
    bl_label = "Specials"

    def draw(self, context):
        layout = self.layout

        pie = layout.menu_pie()
        # Load node groups dynamically
#Left
        # Use Blender's native Spin invoke so its center and axis are derived
        # from the 3D cursor and current viewport exactly as before. Setting
        # duplicate and angle here keeps the old one-click radial behavior.
        radial = pie.operator("mesh.spin", text="Duplicate Radial")
        radial.dupli = True
        radial.angle = math.tau
#Right

#Bottom
        pie.operator("mesh.subdivide_cylinder", text='Subdivide Cylinder')
        pie.operator("object.origin_set_to_bottom", text="Origin to Bottom")
        


#Top
        split = pie.split()
        col = split.column(align=True)
        row = col.row(align=True)
        row.scale_y=1.5
        row.operator("object.quickpipe", text="Quick Pipe")
        row = col.row(align=True)
        row.operator("mesh.bridge_edge_loops", text = "Bridge Smooth").number_cuts=12
        row = col.row(align=True)
        row.scale_y=1.5
        
        pie.operator("view3d.hp_draw", text="Draw Primitives")

#TopLeft
        split = pie.split()
        col = split.column(align=True)
        row = col.row(align=True)
        row.scale_y=1.5
        row.operator("mesh.subdivide", text="Subdivide Smooth").smoothness=1
        row = col.row(align=True)
        row.scale_y=1.5
        row.operator("mesh.subdivide", text="Subdivide Flat").smoothness=0
        row = col.row(align=True)
        row.operator("transform.edge_crease", text="SUBD Crease ").value=1
        row.operator("transform.edge_crease", text="SUBD Un Crease").value=-1
        if operator_exists("object.scv_ot_draw_operator"):
            col.operator("object.scv_ot_draw_operator", text="Keys Viewer")
        col.operator("transform.vertex_random", text="Randomize")
        
        
#TopRight
        split = pie.split()
        col = split.column(align=True)
        row = col.row(align=True)
        row.scale_y=1.5
        row = col.row(align=True)
        row.operator("transform.tosphere", text="Make Round")
        row = col.row(align=True)
        row.operator("mesh.remove_doubles", text="Remove Doubles")
        #pie.operator("transform.tosphere", text="Make Round").value=1
        #pie.operator("mesh.remove_doubles", text="Remove Doubles")
        split = pie.split()
        col = split.column(align=True)
        row = col.row(align=True)
        row.scale_y=1.5
        row = col.row(align=True)
        row.operator("object.add_geo_nodes", text="Array Line").node_group_name = "HP_Array_Line"
        row = col.row(align=True)
        row.operator("object.add_geo_nodes", text="Array Circular").node_group_name = "HP_Array_Circle"
        row = col.row(align=True)
        row.operator("object.add_array_on_curve", text="Array on Curve")
        row = col.row(align=True)
        row.operator("object.add_scatter_on_faces", text="Scatter on Mesh")
        row = col.row(align=True)
        row.operator("object.add_geo_nodes", text="Displacement Noise").node_group_name = "HP_DisplaceNoise"
        row = col.row(align=True)
        row.operator("object.create_lattice_for_selection", text="Lattice")
        

        
#BottomLeft
        split = pie.split()

#BottomRight


class HP_OT_subdivide_cylinder(bpy.types.Operator):
    bl_idname = "mesh.subdivide_cylinder"        # unique identifier for buttons and menu items to reference.
    bl_label = "Subdivide Cylinder"         # display name in the interface.
    bl_options = {'REGISTER', 'UNDO'}  # enable undo for the operator.

    def execute(self, context):
        bpy.ops.mesh.select_edge_loop_multi()
        bpy.ops.mesh.select_edge_ring_multi()
        bpy.ops.mesh.bevel(offset_type='PERCENT', offset_pct=25, affect='EDGES')
        return {'FINISHED'}

class HP_OT_set_origin_to_bottom(Operator):
    bl_idname = "object.origin_set_to_bottom"
    bl_label = "Origin To Bottom"
    bl_description = "Set the Object Origin to the lowest point of each selected object"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if not any(
            [ob.type in {'MESH', 'ARMATURE'} for ob in context.selected_objects]
        ):
            cls.poll_message_set("No mesh or armature objects selected.")
            return False
        return True

    def execute(self, context):
        original_active = context.active_object
        original_mode = original_active.mode if original_active else 'OBJECT'
        selected_objects = list(context.selected_objects)

        if original_active and original_active.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        context.view_layer.update()

        counter = 0
        for obj in selected_objects:
            counter += int(self.origin_to_bottom(context, obj))

        if original_active and original_active.name in context.view_layer.objects:
            context.view_layer.objects.active = original_active
            if original_mode != 'OBJECT':
                try:
                    bpy.ops.object.mode_set(mode=original_mode)
                except RuntimeError:
                    pass
        self.report(
            {'INFO'}, f"Moved the origins of {counter} objects to their lowest point."
        )

        return {'FINISHED'}

    @staticmethod
    def origin_to_bottom(context, obj) -> bool:
        if obj.type not in {'MESH', 'ARMATURE'}:
            return False

        try:
            if obj.type == 'MESH':
                min_z = min(v.co.z for v in obj.data.vertices)
            elif obj.type == 'ARMATURE':
                context.view_layer.objects.active = obj
                bpy.ops.object.mode_set(mode='EDIT')
                min_z = min(
                    min(bone.head.z, bone.tail.z) for bone in obj.data.edit_bones
                )
            else:
                return False
        except ValueError:
            # min([]) would result in this error, so if the object is empty.
            return False

        if obj.type == 'MESH':
            for vert in obj.data.vertices:
                vert.co.z -= min_z
        elif obj.type == 'ARMATURE':
            for bone in obj.data.edit_bones:
                bone.head.z -= min_z
                bone.tail.z -= min_z
            bpy.ops.object.mode_set(mode='OBJECT')

        # Move the object by the matching transformed local offset. This keeps
        # the visible geometry stationary even for rotated, scaled, or parented
        # objects while changing the origin.
        matrix_world = obj.matrix_world.copy()
        matrix_world.translation += matrix_world.to_3x3() @ mathutils.Vector((0.0, 0.0, min_z))
        obj.matrix_world = matrix_world
        return True

###################################################################################
# ADD NODEGROUP TO THE MODIFIER
###################################################################################

# Ensure the specified node group exists in bpy.data.node_groups
def ensure_node_group_loaded(node_group_name):
    if node_group_name not in bpy.data.node_groups:
        with bpy.data.libraries.load(NODE_GROUP_FILE, link=False) as (data_from, data_to):
            if node_group_name in data_from.node_groups:
                data_to.node_groups = [node_group_name]
                print(f"Node group '{node_group_name}' loaded.")
    else:
        print(f"Node group '{node_group_name}' is already available.")

# Function to add a specific Geometry Nodes modifier to the selected object
def add_custom_geo_node(obj, node_group_name):
    ensure_node_group_loaded(node_group_name)
    
    if node_group_name not in bpy.data.node_groups:
        print(f"Node group '{node_group_name}' not found!")
        return
    
    # Add the Geometry Nodes modifier
    modifier = obj.modifiers.new(name=node_group_name, type='NODES')
    modifier.node_group = bpy.data.node_groups[node_group_name]
    print(f"Added Geometry Nodes modifier: {node_group_name}")


def set_nodes_modifier_input(modifier, identifier, value):
    """Set a Geometry Nodes modifier input using Blender 5.2 RNA sockets."""
    inputs = getattr(getattr(modifier, "properties", None), "inputs", None)
    socket = getattr(inputs, identifier, None) if inputs else None
    if socket is None or not hasattr(socket, "value"):
        raise KeyError(f"Geometry Nodes input '{identifier}' was not found")
    socket.value = value


# Add a Geometry Nodes modifier to the curve and set the selected object as an input
def HP_Array_On_Curve(curve, obj, node_group_name):
    ensure_node_group_loaded(node_group_name)

    # Ensure the node group exists
    if node_group_name not in bpy.data.node_groups:
        print(f"Node group '{node_group_name}' not found!")
        return
    
    # Add the Geometry Nodes modifier to the curve
    modifier = curve.modifiers.new(name=node_group_name, type='NODES')
    modifier.node_group = bpy.data.node_groups[node_group_name]

    # Set the object as an input to the Geometry Node group
    set_nodes_modifier_input(modifier, "Socket_3", obj)
    print("Object attached to curve")

# Add a Geometry Nodes modifier to the curve and set the selected object as an input
def HP_Object_On_Faces(obj, obj2, node_group_name):
    ensure_node_group_loaded(node_group_name)

    # Ensure the node group exists
    if node_group_name not in bpy.data.node_groups:
        print(f"Node group '{node_group_name}' not found!")
        return
    
    # Add the Geometry Nodes modifier to the curve
    modifier = obj.modifiers.new(name=node_group_name, type='NODES')
    modifier.node_group = bpy.data.node_groups[node_group_name]

    # Set the object as an input to the Geometry Node group
    set_nodes_modifier_input(modifier, "Socket_3", obj2)
    print("Collection attached to Modifier")


# Operator to add the selected Geometry Nodes modifier
class HP_OBJECT_OT_add_geo_nodes(bpy.types.Operator):
    bl_idname = "object.add_geo_nodes"
    bl_label = "Add Specific Geometry Nodes"
    bl_description = "Add a specific Geometry Nodes modifier to the selected object"
    
    node_group_name: bpy.props.StringProperty()

    def execute(self, context):
        obj = context.object
        if obj and obj.type == 'MESH':  # Ensure the selected object is a mesh
            add_custom_geo_node(obj, self.node_group_name)
            self.report({'INFO'}, f"Added Geometry Nodes modifier: {self.node_group_name}")
        else:
            self.report({'WARNING'}, "Please select a mesh object.")
        return {'FINISHED'}

class HP_OBJECT_OT_add_Array_On_Curve(bpy.types.Operator):
    bl_idname = "object.add_array_on_curve"
    bl_label = "Assign Geometry Nodes to Curve"
    bl_description = "Assign a Geometry Nodes modifier to the selected curve, using the selected object as input"
    
    def execute(self, context):
        selected_objects = context.selected_objects
        if len(selected_objects) != 2:
            self.report({'WARNING'}, "Please select exactly one object and one curve.")
            return {'CANCELLED'}

        # Determine the curve and object
        obj1, obj2 = selected_objects
        curve = obj1 if obj1.type == 'CURVE' else obj2 if obj2.type == 'CURVE' else None
        obj = obj1 if obj1.type != 'CURVE' else obj2 if obj2.type != 'CURVE' else None

        if curve and obj:
            HP_Array_On_Curve(curve, obj, "HP_Array_On_Curve")  # Replace "NodeGroup1" with your node group name
            self.report({'INFO'}, f"Assigned Geometry Nodes modifier to {curve.name} with input {obj.name}")
        else:
            self.report({'WARNING'}, "Please select one curve and one object.")
            return {'CANCELLED'}

        return {'FINISHED'}
    #####################
class HP_OBJECT_OT_add_Scatter_On_Faces(bpy.types.Operator):
    bl_idname = "object.add_scatter_on_faces"
    bl_label = "Assign Geometry Nodes to Curve"
    bl_description = "Assign a Geometry Nodes modifier to the selected curve, using the selected object as input"
    
    def execute(self, context):
        selected_objects = context.selected_objects
        if len(selected_objects) != 2:
            self.report({'WARNING'}, "Please select exactly one object as base and one object to scatter.")
            return {'CANCELLED'}

        # Determine the curve and object
        obj_scatter, obj = selected_objects

        if obj_scatter and obj:
            # Create a vertex group with a specific name on the base object
            vertex_group_name = "Scattering_Mask"
            if vertex_group_name not in obj.vertex_groups:
                obj.vertex_groups.new(name=vertex_group_name)
                self.report({'INFO'}, f"Vertex group '{vertex_group_name}' created on {obj.name}.")
            else:
                self.report({'INFO'}, f"Vertex group '{vertex_group_name}' already exists on {obj.name}.")
            HP_Object_On_Faces(obj, obj_scatter, "HP_ScatterOnFaces") 
            self.report({'INFO'}, f"Assigned Geometry Nodes modifier to {obj.name} with input {obj_scatter.name}")
        else:
            self.report({'WARNING'}, "Please two objects")
            return {'CANCELLED'}

        return {'FINISHED'}
   
def findSelectedObjectsBBoxWithRotation(objs):
    """
    Calculate the oriented bounding box for multiple objects,
    taking into account their average rotation.
    """
    bbox_min = mathutils.Vector((float('inf'), float('inf'), float('inf')))
    bbox_max = mathutils.Vector((float('-inf'), float('-inf'), float('-inf')))
    
    # Sum of rotation matrices
    rotation_sum = mathutils.Matrix.Identity(3)
    object_count = len(objs)

    for ob in objs:
        for corner in ob.bound_box:
            # Transform corner to world coordinates
            world_corner = ob.matrix_world @ mathutils.Vector(corner)
            bbox_min.x = min(bbox_min.x, world_corner.x)
            bbox_min.y = min(bbox_min.y, world_corner.y)
            bbox_min.z = min(bbox_min.z, world_corner.z)
            bbox_max.x = max(bbox_max.x, world_corner.x)
            bbox_max.y = max(bbox_max.y, world_corner.y)
            bbox_max.z = max(bbox_max.z, world_corner.z)
        
        # Add object's rotation to the sum
        rotation_sum += ob.matrix_world.to_3x3()

    # Scale the summed matrix to get the average rotation
    avg_rotation = rotation_sum * (1.0 / object_count)

    # Convert average rotation to 4x4 for transformations
    avg_rotation_4x4 = avg_rotation.to_4x4()

    # Calculate the middle and scale of the bounding box
    middle = (bbox_max + bbox_min) / 2
    scale = (bbox_max - bbox_min)

    return middle, scale, avg_rotation_4x4


def create_lattice_for_selected_objects(context, divisions=(3, 3, 3), interp="KEY_BSPLINE"):
    # Calculate bounding box with average rotation
    middle, scale, avg_rotation = findSelectedObjectsBBoxWithRotation(context.selected_objects)

    # Create the lattice
    lattice = createLatticeObject(
        context,
        loc=middle,
        scale=scale,
        rot=avg_rotation.to_euler(),
        divisions=divisions,
        interp=interp
    )

    # Add lattice modifiers to all selected objects
    for obj in context.selected_objects:
        if obj.type == 'MESH':
            lattice_modifier = obj.modifiers.new(name="Lattice", type='LATTICE')
            lattice_modifier.object = lattice

    print(f"Lattice created for {len(context.selected_objects)} objects.")
    return lattice


def createLatticeObject(context, loc=mathutils.Vector((0.0, 0.0, 0.0)), scale=mathutils.Vector((1, 1, 1)),
                        rot=mathutils.Euler((0.0, 0.0, 0.0)), name=".latticetemp", 
                        divisions=[2, 2, 2], interp="KEY_BSPLINE", isoutside=True):
    # Create lattice data
    lat = bpy.data.lattices.new(name)
    ob = bpy.data.objects.new(name, lat)

    # Set lattice properties
    ob.data.use_outside = isoutside
    ob.data.points_u = divisions[0]
    ob.data.points_v = divisions[1]
    ob.data.points_w = divisions[2]

    ob.data.interpolation_type_u = interp
    ob.data.interpolation_type_v = interp
    ob.data.interpolation_type_w = interp

    # Link lattice to scene
    scene = context.scene
    scene.collection.objects.link(ob)

    # Set lattice location, scale, and rotation
    ob.location = loc
    ob.scale = scale
    ob.rotation_euler = rot

    return ob



class OBJECT_OT_create_lattice_for_selection(bpy.types.Operator):
    """Create a lattice for selected objects"""
    bl_idname = "object.create_lattice_for_selection"
    bl_label = "Create Lattice for Selection"
    bl_options = {'REGISTER', 'UNDO'}

    divisions: bpy.props.IntVectorProperty(
        name="Divisions",
        default=(3, 3, 3),
        size=3,
        min=2
    )
    interp: bpy.props.EnumProperty(
        name="Interpolation",
        items=[
            ('KEY_LINEAR', "Linear", ""),
            ('KEY_CARDINAL', "Cardinal", ""),
            ('KEY_BSPLINE', "B-Spline", "")
        ],
        default='KEY_BSPLINE'
    )

    def execute(self, context):
        create_lattice_for_selected_objects(context, divisions=self.divisions, interp=self.interp)
        return {'FINISHED'}





classes = (
    HP_MT_pie_specials,
    HP_MT_pie_modifiers,
    HC_OT_outline_toggle,
    HP_OT_subdivide_cylinder,
    HP_OT_set_origin_to_bottom,
    HP_OBJECT_OT_add_geo_nodes,
    HP_OBJECT_OT_add_Array_On_Curve,
    OBJECT_OT_create_lattice_for_selection,
    HP_OBJECT_OT_add_Scatter_On_Faces,
)
register, unregister = bpy.utils.register_classes_factory(classes)


if __name__ == "__main__":
    register()
