@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Horizon-Config-2.0-Portable.ps1" -BlenderDir "%~1"
if errorlevel 1 (
  echo.
  echo Horizon Config 2.0 installation did not complete.
  pause
  exit /b 1
)
echo.
pause
