
bl_info = {
    "name": "Pie Extra",
    "description": "",
    "author": "Vaughan Ling",
    "version": (0, 1, 0),
    "blender": (2, 80, 0),
    "location": "",
    "warning": "",
    "wiki_url": "",
    "category": "Pie Menu"
    }

import bpy
from bpy.types import Menu
from bpy.types import Operator
from bpy.props import BoolProperty
from mathutils import Matrix
from bpy.props import StringProperty

class HP_MT_pie_extra(Menu):
    bl_label = "Extra"
    def draw(self, context):
        layout = self.layout
        view = context.space_data
        obj = context.active_object
        pie = layout.menu_pie()
        # Left
        pie.separator()
        

        # Right
        pie.separator()


        # Bottom
        pie.operator("object.origin_set_to_bottom", text="Origin -> Bottom", icon='TRIA_DOWN')


        # Top

        
        # Top Left
            
        

        
        # Top Right
        
        
        # Bottom Left
        

        # Bottom Right
            

        
   
classes = (
    HP_MT_pie_extra,
)

register, unregister = bpy.utils.register_classes_factory(classes)

if __name__ == "__main__":
    register()
